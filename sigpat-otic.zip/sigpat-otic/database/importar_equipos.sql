-- =====================================================================
-- SIGPAT-OTIC - Importación de equipos desde Excel
-- Origen : INVENTARIO 2026 (1).xlsx
-- Fecha  : 2026-09-29 17:22:27
-- Equipos: 181
--
-- Importar en phpMyAdmin: seleccione la base de datos > pestaña Importar.
-- Requisitos: la tabla equipos debe estar vacía (o sin estas series) y
-- debe existir el usuario del sistema "admin" (autor de los registros).
-- Todo se ejecuta en una transacción: si algo falla no se guarda nada.
-- =====================================================================

SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
SET time_zone = '-05:00';
START TRANSACTION;

SET @usr = (SELECT id FROM usuarios_sistema WHERE usuario = 'admin' AND activo = 1 LIMIT 1);
SET @vida = COALESCE((SELECT CAST(valor AS UNSIGNED) FROM parametros WHERE clave = 'vida_util_meses_default'), 48);

-- Oficina: Dirección Académica
SET @of1 = (SELECT id FROM oficinas WHERE nombre = 'Dirección Académica' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Dirección Académica', NULL, 'DIRECCION' FROM DUAL WHERE @of1 IS NULL;
SET @of1 = COALESCE(@of1, (SELECT id FROM oficinas WHERE nombre = 'Dirección Académica' AND padre_id <=> NULL LIMIT 1));

-- Oficina: Dpto. Evaluación
SET @of2 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Evaluación' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Evaluación', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of2 IS NULL;
SET @of2 = COALESCE(@of2, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Evaluación' AND padre_id <=> @of1 LIMIT 1));

-- Personal: JAIME RODRIGUEZ
SET @pe1 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JAIME RODRIGUEZ' OR (nombres = 'Jaime' AND apellidos = 'Rodriguez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jaime', 'Rodriguez', @of2 FROM DUAL WHERE @pe1 IS NULL;
SET @pe1 = COALESCE(@pe1, (SELECT id FROM personal WHERE nombres = 'Jaime' AND apellidos = 'Rodriguez' ORDER BY id DESC LIMIT 1));

-- Equipo 1: PCS ASIGNADAS fila 2
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '85Q3813', NULL, '57196', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-72', 'E4:54:E8:CB:92:DA', '192.168.8.58', '40:5B:D8:46:AC:47', @of2, @pe1, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 2]
Último mantenimiento: 02/02/2026
Vida útil propuesta (meses): 8
Baja sugerida: 02/10/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6ABF4)
Usuario de Windows: jhidalgoa
Fecha BIOS: 25/04/2023
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1037983466
Cable de red: REQUIERE CAMBIO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15962'), (@eq, 2025, '1195');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of2, @pe1, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 2: PCS ASIGNADAS fila 3
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G6', '5CD9432YJY', NULL, '55764', 'Intel(R) Core(TM) i7-8565U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-107', '04:0E:3C:93:55:FB', '192.168.7.166', '28:7F:CF:73:20:E9', @of2, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 3]
Último mantenimiento: 28/04/2026
Vida útil propuesta (meses): 9
Baja sugerida: 28/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97F12)
Usuario de Windows: rcorreac
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13648'), (@eq, 2025, '1411');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of2, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: YUSSANA SUAZO
SET @pe2 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'YUSSANA SUAZO' OR (nombres = 'Yussana' AND apellidos = 'Suazo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Yussana', 'Suazo', @of2 FROM DUAL WHERE @pe2 IS NULL;
SET @pe2 = COALESCE(@pe2, (SELECT id FROM personal WHERE nombres = 'Yussana' AND apellidos = 'Suazo' ORDER BY id DESC LIMIT 1));

-- Equipo 3: PCS ASIGNADAS fila 4
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WXX', NULL, '53542', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-102', 'F8:0D:AC:13:33:38', '192.168.7.199', 'AC:12:03:87:16:17', @of2, @pe2, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 4]
Último mantenimiento: 01/05/2026
Vida útil propuesta (meses): 9
Baja sugerida: 01/02/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97AE9)
Usuario de Windows: cquispec
Fecha BIOS: 14/01/2025
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14040'), (@eq, 2025, '1076');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of2, @pe2, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: NESTOR APAZA HONORI
SET @pe3 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'NESTOR APAZA HONORI' OR (nombres = 'Nestor' AND apellidos = 'Apaza Honori') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Nestor', 'Apaza Honori', @of2 FROM DUAL WHERE @pe3 IS NULL;
SET @pe3 = COALESCE(@pe3, (SELECT id FROM personal WHERE nombres = 'Nestor' AND apellidos = 'Apaza Honori' ORDER BY id DESC LIMIT 1));

-- Equipo 4: PCS ASIGNADAS fila 5
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CQXQNY2', NULL, '56995', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-44', 'E4:54:E8:9B:24:7C', NULL, 'C0:B5:D7:A3:0F:4D', @of2, @pe3, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 5]
Último mantenimiento: 26/01/2026
Vida útil propuesta (meses): 8
Baja sugerida: 26/09/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A30B)
Usuario de Windows: napazah
Fecha BIOS: 25/03/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.9.229
Sophos: ACTIVADO
AnyDesk ID: 1519405366
Cable de red: REQUIERE CAMBIO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16330'), (@eq, 2025, '1184');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of2, @pe3, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Diplomados
SET @of3 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Diplomados' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Diplomados', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of3 IS NULL;
SET @of3 = COALESCE(@of3, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Diplomados' AND padre_id <=> @of1 LIMIT 1));

-- Personal: JORGE HIDALGO AGUILAR
SET @pe4 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JORGE HIDALGO AGUILAR' OR (nombres = 'Jorge' AND apellidos = 'Hidalgo Aguilar') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jorge', 'Hidalgo Aguilar', @of3 FROM DUAL WHERE @pe4 IS NULL;
SET @pe4 = COALESCE(@pe4, (SELECT id FROM personal WHERE nombres = 'Jorge' AND apellidos = 'Hidalgo Aguilar' ORDER BY id DESC LIMIT 1));

-- Equipo 5: PCS ASIGNADAS fila 6
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '62QHT13', NULL, '57214', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-78', 'E4:54:E8:D1:13:4D', '192.168.9.101', 'E8:6F:38:45:49:EB', @of3, @pe4, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 6]
Último mantenimiento: 25/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 25/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69522)
Usuario de Windows: sgarciaa
Fecha BIOS: 08/06/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1543933552', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15344'), (@eq, 2025, '1269');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of3, @pe4, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 6: PCS ASIGNADAS fila 7
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WFM', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, NULL, 'PC2020-115', 'F8:0D:AC:13:37:63', NULL, 'AC:12:03:8B:A1:4B', @of3, @pe4, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 7]
Último mantenimiento: 12/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 12/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC37)
Usuario de Windows: sgarciaa
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 17', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14033'), (@eq, 2025, '1211');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of3, @pe4, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: CARLOS SEGUNDO JARA SALAZAR
SET @pe5 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CARLOS SEGUNDO JARA SALAZAR' OR (nombres = 'Carlos Segundo' AND apellidos = 'Jara Salazar') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Carlos Segundo', 'Jara Salazar', @of3 FROM DUAL WHERE @pe5 IS NULL;
SET @pe5 = COALESCE(@pe5, (SELECT id FROM personal WHERE nombres = 'Carlos Segundo' AND apellidos = 'Jara Salazar' ORDER BY id DESC LIMIT 1));

-- Equipo 7: PCS ASIGNADAS fila 8
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM5Z3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-13', 'E4:54:E8:9B:1C:00', '192.168.7.135', 'EC:5C:68:B6:F5:A7', @of3, @pe5, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 8]
Observación: FALTA DISCO SOLIDO
Último mantenimiento: 27/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 27/06/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A302)
Usuario de Windows: cjaras
Fecha BIOS: 17/06/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
Sophos: ACTIVADO
AnyDesk ID: 526060405', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16322'), (@eq, 2025, '1215');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of3, @pe5, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 8: PCS ASIGNADAS fila 9
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WHB', NULL, '55771', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, NULL, 'PC2020-123', 'F8:0D:AC:13:37:3A', '192.168.8.162', 'AC:12:03:85:A6:0B', @of3, @pe5, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 9]
Último mantenimiento: 27/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 27/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97F10)
Usuario de Windows: cjaras
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.8.162
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14328'), (@eq, 2025, '1237');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of3, @pe5, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Maestrías
SET @of4 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Maestrías' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Maestrías', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of4 IS NULL;
SET @of4 = COALESCE(@of4, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Maestrías' AND padre_id <=> @of1 LIMIT 1));

-- Personal: FELIPE SANTA CRUZ VILLARREAL
SET @pe6 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'FELIPE SANTA CRUZ VILLARREAL' OR (nombres = 'Felipe Santa' AND apellidos = 'Cruz Villarreal') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Felipe Santa', 'Cruz Villarreal', @of4 FROM DUAL WHERE @pe6 IS NULL;
SET @pe6 = COALESCE(@pe6, (SELECT id FROM personal WHERE nombres = 'Felipe Santa' AND apellidos = 'Cruz Villarreal' ORDER BY id DESC LIMIT 1));

-- Equipo 9: PCS ASIGNADAS fila 10
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '2F1H833', NULL, '57220', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-079', 'E4:54:E8:DA:2A:8A', NULL, '4C:EB:BD:65:ED:45', @of4, @pe6, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 10]
Observación: PC2020-79
Último mantenimiento: 20/01/2026
Vida útil propuesta (meses): 8
Baja sugerida: 20/09/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D696FA)
Usuario de Windows: jlaricom
Fecha BIOS: 08/01/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: WDC WD10EZEX-75WN4A1
IP Wi-Fi: 192.168.9.24
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15815'), (@eq, 2025, '1335');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, @pe6, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 10: PCS ASIGNADAS fila 11
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386X0F', NULL, '55760', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, NULL, 'PC2020-101', 'AC:12:03:8C:D2:41', NULL, 'C0:B5:D7:A4:58:5B', @of4, @pe6, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 11]
Último mantenimiento: 04/02/2026
Vida útil propuesta (meses): 8
Baja sugerida: 04/10/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC32)
Usuario de Windows: fsantacruzv
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14307'), (@eq, 2025, '1327');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, @pe6, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JOSE CALAMBROGIO CABRERA
SET @pe7 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSE CALAMBROGIO CABRERA' OR (nombres = 'Jose' AND apellidos = 'Calambrogio Cabrera') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jose', 'Calambrogio Cabrera', @of4 FROM DUAL WHERE @pe7 IS NULL;
SET @pe7 = COALESCE(@pe7, (SELECT id FROM personal WHERE nombres = 'Jose' AND apellidos = 'Calambrogio Cabrera' ORDER BY id DESC LIMIT 1));

-- Equipo 11: PCS ASIGNADAS fila 12
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'G2QHT13', NULL, '57009', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-58', 'E4:54:E8:D1:14:70', '192.168.7.115', 'E8:6F:38:45:B9:B9', @of4, @pe7, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 12]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 8
Baja sugerida: 01/02/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D695F6)
Usuario de Windows: jcalambrogioc
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 11
AnyDesk ID: 1983757787', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15813'), (@eq, 2025, '1315');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, @pe7, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: RICARDO DOMINGUEZ PASCO
SET @pe8 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'RICARDO DOMINGUEZ PASCO' OR (nombres = 'Ricardo' AND apellidos = 'Dominguez Pasco') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Ricardo', 'Dominguez Pasco', @of4 FROM DUAL WHERE @pe8 IS NULL;
SET @pe8 = COALESCE(@pe8, (SELECT id FROM personal WHERE nombres = 'Ricardo' AND apellidos = 'Dominguez Pasco' ORDER BY id DESC LIMIT 1));

-- Equipo 12: PCS ASIGNADAS fila 13
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'LENOVO', 'Lenovo 520-15IKB 81BF', 'PF0YTR26', NULL, NULL, 'Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz', 8, 'HDD', 932, NULL, 'PC2020-06', NULL, NULL, NULL, @of4, @pe8, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 13]
Observación: FALTA DISCO SOLIDO
Último mantenimiento: 04/02/2026
Vida útil propuesta (meses): 5
Baja sugerida: 04/07/2026
Antigüedad: 5 AÑOS
Fecha BIOS: 01/05/2018
Núcleos/hilos CPU: 4/8
Modelo de disco: ST1000LM035-1RK173
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15334'), (@eq, 2025, '1213');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, @pe8, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 13: PCS ASIGNADAS fila 14
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GJ8', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2019-06', '10:E7:C6:B4:C4:CB', '192.168.7.205', NULL, @of4, @pe8, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 14]
Último mantenimiento: 16/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 16/12/2026
Antigüedad: 5 AÑOS
Usuario de Windows: rdominguezp
Fecha BIOS: 25/07/2018
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15822'), (@eq, 2025, '1322');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, @pe8, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Postgrados
SET @of5 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Postgrados' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Postgrados', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of5 IS NULL;
SET @of5 = COALESCE(@of5, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Postgrados' AND padre_id <=> @of1 LIMIT 1));

-- Personal: PEDRO ROMULO BULEJE BULEJE
SET @pe9 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PEDRO ROMULO BULEJE BULEJE' OR (nombres = 'Pedro Romulo' AND apellidos = 'Buleje Buleje') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Pedro Romulo', 'Buleje Buleje', @of5 FROM DUAL WHERE @pe9 IS NULL;
SET @pe9 = COALESCE(@pe9, (SELECT id FROM personal WHERE nombres = 'Pedro Romulo' AND apellidos = 'Buleje Buleje' ORDER BY id DESC LIMIT 1));

-- Equipo 14: PCS ASIGNADAS fila 15
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GML', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2019-04', '10:E7:C6:B4:C0:5D', '192.168.7.152', NULL, @of5, @pe9, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 15]
Observación: FALTA DISCO SOLIDO
Último mantenimiento: 02/05/2026
Vida útil propuesta (meses): 2
Baja sugerida: 02/07/2026
Antigüedad: 5 AÑOS
Usuario de Windows: pbulejeb
Fecha BIOS: 16/04/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: WDC WD10EZEX-60WN4A0
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13968'), (@eq, 2025, '1345');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of5, @pe9, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 15: PCS ASIGNADAS fila 16
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0384NQR', NULL, '55766', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-103', 'F8:0D:AC:12:A0:7B', '192.168.7.170', NULL, @of5, @pe9, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 16]
Último mantenimiento: 19/05/2026
Vida útil propuesta (meses): 9
Baja sugerida: 19/02/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97EF3)
Usuario de Windows: pbulejeb
Fecha BIOS: 08/09/2023
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO
AnyDesk ID: 489206352', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13186'), (@eq, 2025, '1341');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of5, @pe9, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: RICARDO JESUS QUINTANILLA QUILIANO
SET @pe10 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'RICARDO JESUS QUINTANILLA QUILIANO' OR (nombres = 'Ricardo Jesus' AND apellidos = 'Quintanilla Quiliano') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Ricardo Jesus', 'Quintanilla Quiliano', @of5 FROM DUAL WHERE @pe10 IS NULL;
SET @pe10 = COALESCE(@pe10, (SELECT id FROM personal WHERE nombres = 'Ricardo Jesus' AND apellidos = 'Quintanilla Quiliano' ORDER BY id DESC LIMIT 1));

-- Equipo 16: PCS ASIGNADAS fila 17
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM684Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-12', 'E4:54:E8:A1:63:E7', '192.168.7.175', 'EC:5C:68:B7:A2:45', @of5, @pe10, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 17]
Último mantenimiento: 19/03/2026
Vida útil propuesta (meses): 8
Baja sugerida: 19/11/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A1656)
Usuario de Windows: rquintanillaq
Fecha BIOS: 17/06/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
Sophos: ACTIVADO
AnyDesk ID: 950473806', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13979'), (@eq, 2025, '1352');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of5, @pe10, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 17: PCS ASIGNADAS fila 18
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WF0', NULL, '55759', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 238, NULL, NULL, NULL, NULL, NULL, @of5, @pe10, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 18]
Último mantenimiento: 18/05/2026
Baja sugerida: 18/05/2026
Antigüedad: 5 AÑOS
Usuario de Windows: rquintanillaq
Núcleos/hilos CPU: 4/8
Modelo de disco: TEAM TM8FP6256G
Sophos: ACTIVADO
Hostname PC2020-115 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15033'), (@eq, 2025, '1343');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of5, @pe10, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 18: PCS ASIGNADAS fila 19
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WGX', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 238, NULL, 'PC2020-111', 'AC:12:03:88:2F:BB', '192.168.7.108', NULL, @of5, @pe10, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 19]
Último mantenimiento: 18/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 18/01/2027
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 0000_0006_0000_0000_3A5A_2702_3000_0FE8)
Usuario de Windows: rquintanillaq
Núcleos/hilos CPU: 4/8
Modelo de disco: TEAM TM8FP6256G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14025'), (@eq, 2025, '1342');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of5, @pe10, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: GERARDO RAMOS HUARANGA
SET @pe11 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'GERARDO RAMOS HUARANGA' OR (nombres = 'Gerardo' AND apellidos = 'Ramos Huaranga') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Gerardo', 'Ramos Huaranga', @of1 FROM DUAL WHERE @pe11 IS NULL;
SET @pe11 = COALESCE(@pe11, (SELECT id FROM personal WHERE nombres = 'Gerardo' AND apellidos = 'Ramos Huaranga' ORDER BY id DESC LIMIT 1));

-- Equipo 19: PCS ASIGNADAS fila 21
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLX14Y2', NULL, '57122', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-45', 'E4:54:E8:A1:36:89', '192.168.8.78', 'EC:5C:68:B8:8B:ED', @of1, @pe11, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 21]
Último mantenimiento: 02/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 02/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69517)
Usuario de Windows: napazah
Fecha BIOS: 31/08/2023
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 715015923', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15302'), (@eq, 2025, '1403');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of1, @pe11, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: DARINA CASTRO RENTERIA
SET @pe12 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'DARINA CASTRO RENTERIA' OR (nombres = 'Darina' AND apellidos = 'Castro Renteria') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Darina', 'Castro Renteria', @of1 FROM DUAL WHERE @pe12 IS NULL;
SET @pe12 = COALESCE(@pe12, (SELECT id FROM personal WHERE nombres = 'Darina' AND apellidos = 'Castro Renteria' ORDER BY id DESC LIMIT 1));

-- Equipo 20: PCS ASIGNADAS fila 22
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'C2QHT13', NULL, '17772', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-69', 'E4:54:E8:D1:14:3E', '192.168.8.130', 'E8:6F:38:45:47:51', @of1, @pe12, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 22]
Último mantenimiento: 16/01/2026
Vida útil propuesta (meses): 8
Baja sugerida: 16/09/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A644)
Usuario de Windows: dcastror
Fecha BIOS: 18/03/2022
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15281'), (@eq, 2025, '1386');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of1, @pe12, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 21: PCS ASIGNADAS fila 23
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WBG', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2024-02', 'F8:0D:AC:13:39:94', NULL, NULL, @of1, @pe12, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 23]
Último mantenimiento: 03/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 03/10/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69523)
Usuario de Windows: ndelgadov
Fecha BIOS: 23/08/2024
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14326'), (@eq, 2025, '1251');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of1, @pe12, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Aulas Virtuales (Maestrías)
SET @of6 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Aulas Virtuales (Maestrías)' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Aulas Virtuales (Maestrías)', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of6 IS NULL;
SET @of6 = COALESCE(@of6, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Aulas Virtuales (Maestrías)' AND padre_id <=> @of1 LIMIT 1));

-- Personal: CARMEN LUISA ALVAREZ ARANZAMENDI
SET @pe13 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CARMEN LUISA ALVAREZ ARANZAMENDI' OR (nombres = 'Carmen Luisa' AND apellidos = 'Alvarez Aranzamendi') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Carmen Luisa', 'Alvarez Aranzamendi', @of6 FROM DUAL WHERE @pe13 IS NULL;
SET @pe13 = COALESCE(@pe13, (SELECT id FROM personal WHERE nombres = 'Carmen Luisa' AND apellidos = 'Alvarez Aranzamendi' ORDER BY id DESC LIMIT 1));

-- Equipo 22: PCS ASIGNADAS fila 24
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GNQ', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2018-01', '10:E7:C6:B4:C2:28', '192.168.8.69', NULL, @of6, @pe13, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 24]
Observación: PROCESADOR ,CULER YA DESGASTADO
Último mantenimiento: 28/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 28/06/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A2FB)
Usuario de Windows: calvareza
Fecha BIOS: 16/04/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15353'), (@eq, 2025, '1287');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe13, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MAURO
SET @pe14 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MAURO' OR (nombres = 'Mauro' AND apellidos = '-') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Mauro', '-', @of6 FROM DUAL WHERE @pe14 IS NULL;
SET @pe14 = COALESCE(@pe14, (SELECT id FROM personal WHERE nombres = 'Mauro' AND apellidos = '-' ORDER BY id DESC LIMIT 1));

-- Equipo 23: PCS ASIGNADAS fila 25
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GK2', NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, 'PC2020-20', NULL, NULL, NULL, @of6, @pe14, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 25]
Observación: EQUIPO CON FALLAS
Último mantenimiento: 23/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 23/06/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6AC3D)
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13733'), (@eq, 2025, '1879');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe14, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: BRAYHAN RAMIREZ CONTRERAS
SET @pe15 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'BRAYHAN RAMIREZ CONTRERAS' OR (nombres = 'Brayhan' AND apellidos = 'Ramirez Contreras') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Brayhan', 'Ramirez Contreras', @of6 FROM DUAL WHERE @pe15 IS NULL;
SET @pe15 = COALESCE(@pe15, (SELECT id FROM personal WHERE nombres = 'Brayhan' AND apellidos = 'Ramirez Contreras' ORDER BY id DESC LIMIT 1));

-- Equipo 24: PCS ASIGNADAS fila 26
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'CKQ3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 11 Pro', 'PC2020-82', 'E4:54:E8:CB:BA:02', '192.168.7.156', '40:5B:D8:7C:1B:F9', @of6, @pe15, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 26]
Último mantenimiento: 03/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 03/01/2027
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE530)
Usuario de Windows: bramirezc
Fecha BIOS: 08/01/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO
AnyDesk ID: 1302874085', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16335'), (@eq, 2025, '1243');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe15, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 25: PCS ASIGNADAS fila 27
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WK4', NULL, '56227', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, NULL, 'PC2020-104', NULL, NULL, NULL, @of6, @pe15, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 27]
Último mantenimiento: 19/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 19/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97AEC)
Usuario de Windows: bramirezc
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14024'), (@eq, 2025, '1212');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe15, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: CLAUDIO ENRIQUE AYALA GALVAN
SET @pe16 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CLAUDIO ENRIQUE AYALA GALVAN' OR (nombres = 'Claudio Enrique' AND apellidos = 'Ayala Galvan') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Claudio Enrique', 'Ayala Galvan', @of6 FROM DUAL WHERE @pe16 IS NULL;
SET @pe16 = COALESCE(@pe16, (SELECT id FROM personal WHERE nombres = 'Claudio Enrique' AND apellidos = 'Ayala Galvan' ORDER BY id DESC LIMIT 1));

-- Equipo 26: PCS ASIGNADAS fila 28
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '21Q3813', NULL, '57231', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-71', 'E4:54:E8:CB:BA:29', '192.168.7.140', '40:5B:D8:A5:66:7F', @of6, @pe16, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 28]
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 29/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69933)
Usuario de Windows: cayalag
Fecha BIOS: 08/06/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15845'), (@eq, 2025, '1294');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe16, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MAXIMO RAMIREZ JULCA
SET @pe17 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MAXIMO RAMIREZ JULCA' OR (nombres = 'Maximo' AND apellidos = 'Ramirez Julca') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Maximo', 'Ramirez Julca', @of6 FROM DUAL WHERE @pe17 IS NULL;
SET @pe17 = COALESCE(@pe17, (SELECT id FROM personal WHERE nombres = 'Maximo' AND apellidos = 'Ramirez Julca' ORDER BY id DESC LIMIT 1));

-- Equipo 27: PCS ASIGNADAS fila 29
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JKW3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-38', 'E4:54:E8:98:FC:1A', '192.168.7.142', 'C0:B5:D7:93:86:F5', @of6, @pe17, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 29]
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 29/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C63CC4)
Usuario de Windows: rquintanillaq
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13956'), (@eq, 2025, '1276');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of6, @pe17, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dirección Administrativa
SET @of7 = (SELECT id FROM oficinas WHERE nombre = 'Dirección Administrativa' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Dirección Administrativa', NULL, 'DIRECCION' FROM DUAL WHERE @of7 IS NULL;
SET @of7 = COALESCE(@of7, (SELECT id FROM oficinas WHERE nombre = 'Dirección Administrativa' AND padre_id <=> NULL LIMIT 1));

-- Oficina: Dpto. Finanzas
SET @of8 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Finanzas' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Dpto. Finanzas', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of8 IS NULL;
SET @of8 = COALESCE(@of8, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Finanzas' AND padre_id <=> @of7 LIMIT 1));

-- Personal: JORGE LUIS OLAYA COPAJA
SET @pe18 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JORGE LUIS OLAYA COPAJA' OR (nombres = 'Jorge Luis' AND apellidos = 'Olaya Copaja') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jorge Luis', 'Olaya Copaja', @of8 FROM DUAL WHERE @pe18 IS NULL;
SET @pe18 = COALESCE(@pe18, (SELECT id FROM personal WHERE nombres = 'Jorge Luis' AND apellidos = 'Olaya Copaja' ORDER BY id DESC LIMIT 1));

-- Equipo 28: PCS ASIGNADAS fila 30
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '37Q3813', NULL, '57029', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'JOLAYAC', 'E4:54:E8:CB:49:09', '192.168.8.20', '40:5B:D8:46:05:AB', @of8, @pe18, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 30]
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 29/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62E83)
Usuario de Windows: jolayac
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12977'), (@eq, 2025, '1007');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe18, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ELIANA
SET @pe19 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ELIANA' OR (nombres = 'Eliana' AND apellidos = '-') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Eliana', '-', @of8 FROM DUAL WHERE @pe19 IS NULL;
SET @pe19 = COALESCE(@pe19, (SELECT id FROM personal WHERE nombres = 'Eliana' AND apellidos = '-' ORDER BY id DESC LIMIT 1));

-- Equipo 29: PCS ASIGNADAS fila 31
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0384NSQ', NULL, '2628', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-120', 'AC:12:03:89:D3:E8', '192.168.7.221', NULL, @of8, @pe19, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 31]
Último mantenimiento: 04/06/2026
Vida útil propuesta (meses): 7
Baja sugerida: 04/01/2027
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62CC3)
Usuario de Windows: mvillarr
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14023');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe19, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JOSE MANUEL CHAVEZ ÑAHUI
SET @pe20 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSE MANUEL CHAVEZ ÑAHUI' OR (nombres = 'Jose Manuel' AND apellidos = 'Chavez Ñahui') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jose Manuel', 'Chavez Ñahui', @of8 FROM DUAL WHERE @pe20 IS NULL;
SET @pe20 = COALESCE(@pe20, (SELECT id FROM personal WHERE nombres = 'Jose Manuel' AND apellidos = 'Chavez Ñahui' ORDER BY id DESC LIMIT 1));

-- Equipo 30: PCS ASIGNADAS fila 32
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GJ1', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'FINANZAS', '10:E7:C6:B4:C0:F4', NULL, NULL, @of8, @pe20, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 32]
Observación: PC2019-10
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 29/12/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AEA39)
Usuario de Windows: jalberto
Fecha BIOS: 16/04/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO
IP LAN 192.168.8.20 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13220'), (@eq, 2025, '1016');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe20, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: CESAR APOLINARIO MARQUEZ CARUSSO
SET @pe21 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CESAR APOLINARIO MARQUEZ CARUSSO' OR (nombres = 'Cesar Apolinario' AND apellidos = 'Marquez Carusso') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Cesar Apolinario', 'Marquez Carusso', @of8 FROM DUAL WHERE @pe21 IS NULL;
SET @pe21 = COALESCE(@pe21, (SELECT id FROM personal WHERE nombres = 'Cesar Apolinario' AND apellidos = 'Marquez Carusso' ORDER BY id DESC LIMIT 1));

-- Equipo 31: PCS ASIGNADAS fila 33
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM624Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-17', 'E4:54:E8:9B:1C:08', '192.168.8.34', 'EC:5C:68:B7:07:7F', @of8, @pe21, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 33]
Último mantenimiento: 03/02/2026
Vida útil propuesta (meses): 8
Baja sugerida: 03/10/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE985)
Usuario de Windows: rherrerar
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13005'), (@eq, 2025, '1038');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe21, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: INNDEVOR MIMBELA TAVARA
SET @pe22 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'INNDEVOR MIMBELA TAVARA' OR (nombres = 'Inndevor' AND apellidos = 'Mimbela Tavara') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Inndevor', 'Mimbela Tavara', @of8 FROM DUAL WHERE @pe22 IS NULL;
SET @pe22 = COALESCE(@pe22, (SELECT id FROM personal WHERE nombres = 'Inndevor' AND apellidos = 'Mimbela Tavara' ORDER BY id DESC LIMIT 1));

-- Equipo 32: PCS ASIGNADAS fila 34
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JDS3Y2', NULL, '55536', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-35', 'E4:54:E8:98:FF:16', '192.168.7.110', 'C0:B5:D7:93:E0:BD', @of8, @pe22, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 34]
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 5
Baja sugerida: 29/09/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62794)
Usuario de Windows: imimbelat
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13679'), (@eq, 2025, '1044');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe22, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MIRIAN SARAY MOLINA YAURES
SET @pe23 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MIRIAN SARAY MOLINA YAURES' OR (nombres = 'Mirian Saray' AND apellidos = 'Molina Yaures') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Mirian Saray', 'Molina Yaures', @of8 FROM DUAL WHERE @pe23 IS NULL;
SET @pe23 = COALESCE(@pe23, (SELECT id FROM personal WHERE nombres = 'Mirian Saray' AND apellidos = 'Molina Yaures' ORDER BY id DESC LIMIT 1));

-- Equipo 33: PCS ASIGNADAS fila 35
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JNR3Y2', NULL, '55538', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'MMOLINAY', 'E4:54:E8:98:FF:08', NULL, 'C0:B5:D7:93:E3:4F', @of8, @pe23, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 35]
Último mantenimiento: 29/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 29/12/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62E3E)
Usuario de Windows: mmolinay
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.5
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12996'), (@eq, 2025, '1050');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe23, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ANA MARIA ALFARO HOYOS
SET @pe24 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ANA MARIA ALFARO HOYOS' OR (nombres = 'Ana Maria' AND apellidos = 'Alfaro Hoyos') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Ana Maria', 'Alfaro Hoyos', @of8 FROM DUAL WHERE @pe24 IS NULL;
SET @pe24 = COALESCE(@pe24, (SELECT id FROM personal WHERE nombres = 'Ana Maria' AND apellidos = 'Alfaro Hoyos' ORDER BY id DESC LIMIT 1));

-- Equipo 34: PCS ASIGNADAS fila 36
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GJY', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2019-130', '10:E7:C6:B4:C1:9C', '192.168.9.22', NULL, @of8, @pe24, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 36]
Observación: PC2019-03
Último mantenimiento: 30/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 30/10/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE9DD)
Usuario de Windows: aalfaroh
Fecha BIOS: 25/07/2018
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12983'), (@eq, 2025, '1030');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, @pe24, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Logística y Abasto
SET @of9 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Logística y Abasto' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Dpto. Logística y Abasto', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of9 IS NULL;
SET @of9 = COALESCE(@of9, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Logística y Abasto' AND padre_id <=> @of7 LIMIT 1));

-- Personal: JOSIP IVAN MARKOVINOVIC QUIJADA
SET @pe25 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSIP IVAN MARKOVINOVIC QUIJADA' OR (nombres = 'Josip Ivan' AND apellidos = 'Markovinovic Quijada') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Josip Ivan', 'Markovinovic Quijada', @of9 FROM DUAL WHERE @pe25 IS NULL;
SET @pe25 = COALESCE(@pe25, (SELECT id FROM personal WHERE nombres = 'Josip Ivan' AND apellidos = 'Markovinovic Quijada' ORDER BY id DESC LIMIT 1));

-- Equipo 35: PCS ASIGNADAS fila 37
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM064Y2', NULL, '55542', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 11 Pro', 'ASESORIA', '54:4E:05:2D:8E:00', NULL, 'EC:5C:68:B8:8B:DB', @of9, @pe25, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 37]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 20/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62CC6)
Usuario de Windows: asis.juridico
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.155
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13763'), (@eq, 2025, '1097');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe25, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MILY JHANET FERNANDEZ ACUÑA
SET @pe26 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MILY JHANET FERNANDEZ ACUÑA' OR (nombres = 'Mily Jhanet' AND apellidos = 'Fernandez Acuña') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Mily Jhanet', 'Fernandez Acuña', @of9 FROM DUAL WHERE @pe26 IS NULL;
SET @pe26 = COALESCE(@pe26, (SELECT id FROM personal WHERE nombres = 'Mily Jhanet' AND apellidos = 'Fernandez Acuña' ORDER BY id DESC LIMIT 1));

-- Equipo 36: PCS ASIGNADAS fila 38
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '7F1H833', NULL, '55529', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'JFERNANDEZA', 'E4:54:E8:DA:1A:6E', '192.168.8.18', '4C:EB:BD:65:F1:89', @of9, @pe26, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 38]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 4
Baja sugerida: 20/08/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C631C7)
Usuario de Windows: jfernandeza
Fecha BIOS: 08/06/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13790'), (@eq, 2025, '1102');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe26, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: KARINA MALACA MONTANE
SET @pe27 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'KARINA MALACA MONTANE' OR (nombres = 'Karina' AND apellidos = 'Malaca Montane') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Karina', 'Malaca Montane', @of9 FROM DUAL WHERE @pe27 IS NULL;
SET @pe27 = COALESCE(@pe27, (SELECT id FROM personal WHERE nombres = 'Karina' AND apellidos = 'Malaca Montane' ORDER BY id DESC LIMIT 1));

-- Equipo 37: PCS ASIGNADAS fila 39
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM114Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-36', 'E4:54:E8:9B:22:29', NULL, 'EC:5C:68:B8:8B:E7', @of9, @pe27, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 39]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 20/06/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A307)
Usuario de Windows: kmalacam
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.51
Sophos: ACTIVADO
AnyDesk ID: 1072944444', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13802'), (@eq, 2025, '1193');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe27, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: YADINA PRINCIPE CONCHA
SET @pe28 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'YADINA PRINCIPE CONCHA' OR (nombres = 'Yadina' AND apellidos = 'Principe Concha') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Yadina', 'Principe Concha', @of9 FROM DUAL WHERE @pe28 IS NULL;
SET @pe28 = COALESCE(@pe28, (SELECT id FROM personal WHERE nombres = 'Yadina' AND apellidos = 'Principe Concha' ORDER BY id DESC LIMIT 1));

-- Equipo 38: PCS ASIGNADAS fila 40
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WFG', NULL, '2645', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-145', NULL, NULL, NULL, @of9, @pe28, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 40]
Último mantenimiento: 21/01/2026
Vida útil propuesta (meses): 7
Baja sugerida: 21/08/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97AB5)
Núcleos/hilos CPU: 4/8
Modelo de disco: WDC WD10SPZX-60Z10T0
Sophos: ACTIVADO
MAC LAN no válida en el Excel: Microsoft Windows 10 Pro', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14051'), (@eq, 2025, '2465');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe28, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 39: PCS ASIGNADAS fila 41
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WHG', NULL, '55765', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-109', NULL, NULL, NULL, @of9, @pe26, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 41]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 7
Baja sugerida: 02/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC35)
Usuario de Windows: jfernandeza
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO
MAC LAN no válida en el Excel: Microsoft Windows 10 Pro', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13830');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe26, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: PEDRO SANCHEZ CABANILLAS
SET @pe29 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PEDRO SANCHEZ CABANILLAS' OR (nombres = 'Pedro' AND apellidos = 'Sanchez Cabanillas') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Pedro', 'Sanchez Cabanillas', @of9 FROM DUAL WHERE @pe29 IS NULL;
SET @pe29 = COALESCE(@pe29, (SELECT id FROM personal WHERE nombres = 'Pedro' AND apellidos = 'Sanchez Cabanillas' ORDER BY id DESC LIMIT 1));

-- Equipo 40: PCS ASIGNADAS fila 42
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WGV', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 238, 'Microsoft Windows 10 Pro', 'PC2020-106', NULL, NULL, NULL, @of9, @pe29, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 42]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 02/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97AE2)
Usuario de Windows: lgonzalesg
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO
MAC LAN no válida en el Excel: Microsoft Windows 10 Pro', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14021'), (@eq, 2025, '1064');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe29, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JOSE LUIS BAUTISTA QUISPE
SET @pe30 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSE LUIS BAUTISTA QUISPE' OR (nombres = 'Jose Luis' AND apellidos = 'Bautista Quispe') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jose Luis', 'Bautista Quispe', @of9 FROM DUAL WHERE @pe30 IS NULL;
SET @pe30 = COALESCE(@pe30, (SELECT id FROM personal WHERE nombres = 'Jose Luis' AND apellidos = 'Bautista Quispe' ORDER BY id DESC LIMIT 1));

-- Equipo 41: PCS ASIGNADAS fila 43
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CD0386WG4', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-94', NULL, NULL, NULL, @of9, @pe30, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 43]
Último mantenimiento: 03/06/2026
Vida útil propuesta (meses): 9
Baja sugerida: 03/03/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC3A)
Usuario de Windows: cfloresm
Núcleos/hilos CPU: 4/8
Modelo de disco: WDC WD10SPZX-60Z10T0
Sophos: ACTIVADO
MAC LAN no válida en el Excel: Microsoft Windows 10 Pro', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13724'), (@eq, 2025, '3037');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe30, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 42: PCS ASIGNADAS fila 44
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'DKQ3813', NULL, '5726', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-15', 'E4:54:E8:CB:BA:1C', NULL, '40:5B:D8:7B:5B:39', @of9, @pe28, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 44]
Observación: PC2020-66
Último mantenimiento: 10/04/2025
Vida útil propuesta (meses): 2
Baja sugerida: 10/06/2025
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62728)
Usuario de Windows: yprincipe
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.27
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13797'), (@eq, 2025, '1079');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe28, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: NICKOLE YOPLAC GARCIA
SET @pe31 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'NICKOLE YOPLAC GARCIA' OR (nombres = 'Nickole' AND apellidos = 'Yoplac Garcia') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Nickole', 'Yoplac Garcia', @of9 FROM DUAL WHERE @pe31 IS NULL;
SET @pe31 = COALESCE(@pe31, (SELECT id FROM personal WHERE nombres = 'Nickole' AND apellidos = 'Yoplac Garcia' ORDER BY id DESC LIMIT 1));

-- Equipo 43: PCS ASIGNADAS fila 45
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM014Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-22', 'E4:54:E8:9B:1B:A9', NULL, 'EC:5C:68:B8:8D:6B', @of9, @pe31, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 45]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 20/06/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854ADFB5)
Usuario de Windows: nyoplacg
Fecha BIOS: 15/06/2020
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
IP Wi-Fi: 192.168.7.68
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13815'), (@eq, 2025, '1090');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe31, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: PILAR REQUE LIZA
SET @pe32 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PILAR REQUE LIZA' OR (nombres = 'Pilar' AND apellidos = 'Reque Liza') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Pilar', 'Reque Liza', @of9 FROM DUAL WHERE @pe32 IS NULL;
SET @pe32 = COALESCE(@pe32, (SELECT id FROM personal WHERE nombres = 'Pilar' AND apellidos = 'Reque Liza' ORDER BY id DESC LIMIT 1));

-- Equipo 44: PCS ASIGNADAS fila 46
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CQZQNY2', NULL, '57245', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'SZEVALLOSR', 'E4:54:E8:9B:0A:A2', NULL, 'C0:B5:D7:A4:58:6B', @of9, @pe32, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 46]
Observación: PC2020-03
Último mantenimiento: 30/04/2026
Vida útil propuesta (meses): 4
Baja sugerida: 30/08/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62CF2)
Usuario de Windows: szevallosr
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.156
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15031'), (@eq, 2025, '1133');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe32, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JUAN DIEGO MEDINA RIVERO
SET @pe33 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JUAN DIEGO MEDINA RIVERO' OR (nombres = 'Juan Diego' AND apellidos = 'Medina Rivero') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Juan Diego', 'Medina Rivero', @of9 FROM DUAL WHERE @pe33 IS NULL;
SET @pe33 = COALESCE(@pe33, (SELECT id FROM personal WHERE nombres = 'Juan Diego' AND apellidos = 'Medina Rivero' ORDER BY id DESC LIMIT 1));

-- Equipo 45: PCS ASIGNADAS fila 47
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GMT', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2019-12', '10:E7:C6:B4:C0:69', NULL, 'B0:19:21:B6:DC:9C', @of9, @pe33, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 47]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 5
Baja sugerida: 20/09/2026
Antigüedad: 5 AÑOS
Disco sólido: SAMSUNG (serie MZVLB512HBJQ-000L7)
Usuario de Windows: jmedinar
Fecha BIOS: 25/07/2018
Núcleos/hilos CPU: 6/12
Modelo de disco: WDC WD10EZEX-60WN4A0
IP Wi-Fi: 192.168.7.128
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13221'), (@eq, 2025, '1117');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe33, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: CLAUDIA CRUZ IZQUIERDO
SET @pe34 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CLAUDIA CRUZ IZQUIERDO' OR (nombres = 'Claudia' AND apellidos = 'Cruz Izquierdo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Claudia', 'Cruz Izquierdo', @of9 FROM DUAL WHERE @pe34 IS NULL;
SET @pe34 = COALESCE(@pe34, (SELECT id FROM personal WHERE nombres = 'Claudia' AND apellidos = 'Cruz Izquierdo' ORDER BY id DESC LIMIT 1));

-- Equipo 46: PCS ASIGNADAS fila 48
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'FF1H833', NULL, '57259', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-66', 'E4:54:E8:DA:2A:E2', NULL, '4C:EB:BD:65:F1:87', @of9, @pe34, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 48]
Último mantenimiento: 16/03/2026
Vida útil propuesta (meses): 3
Baja sugerida: 16/06/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C626FC)
Usuario de Windows: ccruzi
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.55
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13824'), (@eq, 2025, '1125');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, @pe34, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Recursos Humanos
SET @of10 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Recursos Humanos' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Dpto. Recursos Humanos', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of10 IS NULL;
SET @of10 = COALESCE(@of10, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Recursos Humanos' AND padre_id <=> @of7 LIMIT 1));

-- Personal: JAVIER ROLANDO SALCEDO MORALES
SET @pe35 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JAVIER ROLANDO SALCEDO MORALES' OR (nombres = 'Javier Rolando' AND apellidos = 'Salcedo Morales') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Javier Rolando', 'Salcedo Morales', @of10 FROM DUAL WHERE @pe35 IS NULL;
SET @pe35 = COALESCE(@pe35, (SELECT id FROM personal WHERE nombres = 'Javier Rolando' AND apellidos = 'Salcedo Morales' ORDER BY id DESC LIMIT 1));

-- Equipo 47: PCS ASIGNADAS fila 49
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JQX3Y2', NULL, '56914', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', NULL, 'E4:54:E8:98:FE:BC', '192.168.8.102', 'C0:B5:D7:93:7F:39', @of10, @pe35, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 49]
Último mantenimiento: 15/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 15/07/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C63D57)
Usuario de Windows: jsalcedom
Fecha BIOS: 15/06/2020
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
Hostname no válido en el Excel: PMU¥OZV', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13431'), (@eq, 2025, '0858');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of10, @pe35, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: HIPOLITO MARTIN RUIZ VARGAS
SET @pe36 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'HIPOLITO MARTIN RUIZ VARGAS' OR (nombres = 'Hipolito Martin' AND apellidos = 'Ruiz Vargas') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Hipolito Martin', 'Ruiz Vargas', @of10 FROM DUAL WHERE @pe36 IS NULL;
SET @pe36 = COALESCE(@pe36, (SELECT id FROM personal WHERE nombres = 'Hipolito Martin' AND apellidos = 'Ruiz Vargas' ORDER BY id DESC LIMIT 1));

-- Equipo 48: PCS ASIGNADAS fila 50
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'GF1H833', NULL, '55534', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'JBASAURIS', 'E4:54:E8:DA:1F:C5', NULL, '4C:EB:BD:65:F1:83', @of10, @pe36, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 50]
Observación: PC2020-62
Último mantenimiento: 06/03/2026
Vida útil propuesta (meses): 8
Baja sugerida: 06/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A639)
Usuario de Windows: jbasauris
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.116
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 29
AnyDesk ID: 1437622363', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13650'), (@eq, 2025, '0848');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of10, @pe36, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Seguridad
SET @of11 = (SELECT id FROM oficinas WHERE nombre = 'Seguridad' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Seguridad', NULL, 'OFICINA' FROM DUAL WHERE @of11 IS NULL;
SET @of11 = COALESCE(@of11, (SELECT id FROM oficinas WHERE nombre = 'Seguridad' AND padre_id <=> @of7 LIMIT 1));

-- Personal: MANUEL JESUS YOVERA TUESTA
SET @pe37 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MANUEL JESUS YOVERA TUESTA' OR (nombres = 'Manuel Jesus' AND apellidos = 'Yovera Tuesta') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Manuel Jesus', 'Yovera Tuesta', @of11 FROM DUAL WHERE @pe37 IS NULL;
SET @pe37 = COALESCE(@pe37, (SELECT id FROM personal WHERE nombres = 'Manuel Jesus' AND apellidos = 'Yovera Tuesta' ORDER BY id DESC LIMIT 1));

-- Equipo 49: PCS ASIGNADAS fila 51
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8331WPL', NULL, '50071', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2019-131', '10:E7:C6:B4:4B:CB', NULL, NULL, @of11, @pe37, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 51]
Observación: PC2019-07
Último mantenimiento: 13/03/2026
Vida útil propuesta (meses): 8
Baja sugerida: 13/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A16A)
Usuario de Windows: SOPORTE
Fecha BIOS: 16/04/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1468294484
IP LAN 192.168.7.142 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13434'), (@eq, 2025, '0877');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of11, @pe37, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Tópico
SET @of12 = (SELECT id FROM oficinas WHERE nombre = 'Tópico' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Tópico', NULL, 'OFICINA' FROM DUAL WHERE @of12 IS NULL;
SET @of12 = COALESCE(@of12, (SELECT id FROM oficinas WHERE nombre = 'Tópico' AND padre_id <=> @of7 LIMIT 1));

-- Personal: WALTER ISAAC CHIPANA CHAMBE
SET @pe38 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'WALTER ISAAC CHIPANA CHAMBE' OR (nombres = 'Walter Isaac' AND apellidos = 'Chipana Chambe') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Walter Isaac', 'Chipana Chambe', @of12 FROM DUAL WHERE @pe38 IS NULL;
SET @pe38 = COALESCE(@pe38, (SELECT id FROM personal WHERE nombres = 'Walter Isaac' AND apellidos = 'Chipana Chambe' ORDER BY id DESC LIMIT 1));

-- Equipo 50: PCS ASIGNADAS fila 52
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLZY3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-40', 'E4:54:E8:9B:1E:E5', NULL, 'EC:5C:68:B8:8C:E5', @of12, @pe38, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 52]
Último mantenimiento: 04/03/2026
Vida útil propuesta (meses): 6
Baja sugerida: 04/09/2026
Antigüedad: 5 AÑOS
Usuario de Windows: wchipanac
Fecha BIOS: 03/12/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
IP Wi-Fi: 192.168.8.221
Sophos: ACTIVADO
Cable de red: no tiene solido', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13695');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of12, @pe38, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Counter
SET @of13 = (SELECT id FROM oficinas WHERE nombre = 'Counter' AND padre_id <=> @of7 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of7, 'Counter', NULL, 'OFICINA' FROM DUAL WHERE @of13 IS NULL;
SET @of13 = COALESCE(@of13, (SELECT id FROM oficinas WHERE nombre = 'Counter' AND padre_id <=> @of7 LIMIT 1));

-- Equipo 51: PCS ASIGNADAS fila 53
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CR3XNY2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'SEGURIDAD', 'E4:54:E8:9B:0A:7B', '192.168.7.252', NULL, @of13, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 53]
Observación: PC2020-10
Último mantenimiento: 29/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 29/11/2026
Antigüedad: 5 AÑOS
Usuario de Windows: seguridad
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: WDC WD10EZEX-75WN4A1
Sophos: ACTIVADO
MAC Wi-Fi C0:B5:D7:A4:58:5B repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14304'), (@eq, 2025, '0901');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of13, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: GINA PAOLA CHEREQUES SANDOVAL
SET @pe39 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'GINA PAOLA CHEREQUES SANDOVAL' OR (nombres = 'Gina Paola' AND apellidos = 'Chereques Sandoval') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Gina Paola', 'Chereques Sandoval', @of13 FROM DUAL WHERE @pe39 IS NULL;
SET @pe39 = COALESCE(@pe39, (SELECT id FROM personal WHERE nombres = 'Gina Paola' AND apellidos = 'Chereques Sandoval' ORDER BY id DESC LIMIT 1));

-- Equipo 52: PCS ASIGNADAS fila 54
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLV74Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-04', 'E4:54:E8:A1:37:C5', NULL, 'EC:5C:68:B8:8C:E9', @of13, @pe39, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 54]
Último mantenimiento: 24/04/2026
Vida útil propuesta (meses): 7
Baja sugerida: 24/11/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C63540)
Usuario de Windows: gcherequess
Fecha BIOS: 13/07/2023
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.82
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13703');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of13, @pe39, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dirección de Investigación
SET @of14 = (SELECT id FROM oficinas WHERE nombre = 'Dirección de Investigación' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Dirección de Investigación', NULL, 'DIRECCION' FROM DUAL WHERE @of14 IS NULL;
SET @of14 = COALESCE(@of14, (SELECT id FROM oficinas WHERE nombre = 'Dirección de Investigación' AND padre_id <=> NULL LIMIT 1));

-- Personal: LUIS ACUÑA MACURI
SET @pe40 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LUIS ACUÑA MACURI' OR (nombres = 'Luis' AND apellidos = 'Acuña Macuri') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Luis', 'Acuña Macuri', @of14 FROM DUAL WHERE @pe40 IS NULL;
SET @pe40 = COALESCE(@pe40, (SELECT id FROM personal WHERE nombres = 'Luis' AND apellidos = 'Acuña Macuri' ORDER BY id DESC LIMIT 1));

-- Equipo 53: PCS ASIGNADAS fila 55
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8J8W3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-26', 'E4:54:E8:98:FD:B8', NULL, 'C0:B5:D7:93:E3:65', @of14, @pe40, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 55]
Último mantenimiento: 03/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 03/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69838)
Usuario de Windows: lacu¤am
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
IP LAN 192.168.8.18 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14507'), (@eq, 2025, '1479');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe40, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 54: PCS ASIGNADAS fila 56
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'LENOVO', 'Lenovo 520-15IKB 81BF', 'PF0YTSF8', NULL, NULL, 'Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2023-07', 'F8:0D:AC:13:36:8D', NULL, '8C:16:45:4F:63:94', @of14, @pe40, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 56]
Último mantenimiento: 03/06/2026
Vida útil propuesta (meses): 5
Baja sugerida: 03/11/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A16F)
Usuario de Windows: Luis Acuña
Fecha BIOS: 30/06/2020
Núcleos/hilos CPU: 4/8
Modelo de disco: ST1000LM035-1RK172
IP Wi-Fi: 192.168.7.98
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14289');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe40, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: EDWIN CRUZ ASPAJO
SET @pe41 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'EDWIN CRUZ ASPAJO' OR (nombres = 'Edwin' AND apellidos = 'Cruz Aspajo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Edwin', 'Cruz Aspajo', @of14 FROM DUAL WHERE @pe41 IS NULL;
SET @pe41 = COALESCE(@pe41, (SELECT id FROM personal WHERE nombres = 'Edwin' AND apellidos = 'Cruz Aspajo' ORDER BY id DESC LIMIT 1));

-- Equipo 55: PCS ASIGNADAS fila 57
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WL0', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', NULL, 'Microsoft Windows 10 Pro', 'PC2020-125', NULL, NULL, NULL, @of14, @pe41, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 57]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 02/12/2026
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 000_0006_0000_0000_3A5A_2702_3000_0FC5)
Usuario de Windows: EDWIN CRUZ ASPAJO
Núcleos/hilos CPU: 4/8
Modelo de disco: TEAM TM8FP6256G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13843'), (@eq, 2025, '1750');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe41, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ROBERTO MANUEL GALVEZ CASTRO
SET @pe42 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ROBERTO MANUEL GALVEZ CASTRO' OR (nombres = 'Roberto Manuel' AND apellidos = 'Galvez Castro') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Roberto Manuel', 'Galvez Castro', @of14 FROM DUAL WHERE @pe42 IS NULL;
SET @pe42 = COALESCE(@pe42, (SELECT id FROM personal WHERE nombres = 'Roberto Manuel' AND apellidos = 'Galvez Castro' ORDER BY id DESC LIMIT 1));

-- Equipo 56: PCS ASIGNADAS fila 58
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WD0', NULL, '55758', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-105', 'F8:0D:AC:13:36:E2', NULL, 'AC:12:03:8A:BF:E2', @of14, @pe42, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 58]
Último mantenimiento: 19/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 19/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC5F)
Usuario de Windows: rgalvezc
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.9.144
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14329');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe42, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 57: PCS ASIGNADAS fila 59
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'CM044Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-23', 'E4:54:E8:9B:1F:0D', '192.168.7.157', 'EC:5C:68:B8:8D:71', @of14, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 59]
Observación: CUENTA CON DISCO DURO MECANICO
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 8
Baja sugerida: 02/02/2027
Antigüedad: 5 AÑOS
Usuario de Windows: hruizv
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP103
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14428'), (@eq, 2025, '1594');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: RONALD GÜISA BRAVO
SET @pe43 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'RONALD GÜISA BRAVO' OR (nombres = 'Ronald' AND apellidos = 'Güisa Bravo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Ronald', 'Güisa Bravo', @of14 FROM DUAL WHERE @pe43 IS NULL;
SET @pe43 = COALESCE(@pe43, (SELECT id FROM personal WHERE nombres = 'Ronald' AND apellidos = 'Güisa Bravo' ORDER BY id DESC LIMIT 1));

-- Equipo 58: PCS ASIGNADAS fila 60
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '45Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-56', 'E4:54:E8:CB:94:F4', '192.168.0.97', NULL, @of14, @pe43, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 60]
Último mantenimiento: 03/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 03/12/2026
Antigüedad: 5 AÑOS
Usuario de Windows: soporte
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14490');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe43, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 59: PCS ASIGNADAS fila 61
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'ELITEDESK 800 G1', 'MXL4472CHS', NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, 'PC2020-68', NULL, NULL, NULL, @of14, @pe42, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 61]
Último mantenimiento: 20/01/2026
Vida útil propuesta (meses): 5
Baja sugerida: 20/06/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0EE5)
Usuario de Windows: RGALVEZC
Fecha BIOS: 20/01/2026
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12891'), (@eq, 2025, '2620');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe42, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MARTIN NAVARRO
SET @pe44 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MARTIN NAVARRO' OR (nombres = 'Martin' AND apellidos = 'Navarro') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Martin', 'Navarro', @of14 FROM DUAL WHERE @pe44 IS NULL;
SET @pe44 = COALESCE(@pe44, (SELECT id FROM personal WHERE nombres = 'Martin' AND apellidos = 'Navarro' ORDER BY id DESC LIMIT 1));

-- Equipo 60: PCS ASIGNADAS fila 62
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLPY3Y2', NULL, '57227', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-11', 'E4:54:E8:9B:1C:3D', '192.168.7.106', 'EC:5C:68:B7:07:7B', @of14, @pe44, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 62]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 5
Baja sugerida: 01/11/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C6265D)
Usuario de Windows: jgarciap
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14438'), (@eq, 2025, '1530');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe44, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ELSA SULAY PAZ SOTERO
SET @pe45 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ELSA SULAY PAZ SOTERO' OR (nombres = 'Elsa Sulay' AND apellidos = 'Paz Sotero') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Elsa Sulay', 'Paz Sotero', @of14 FROM DUAL WHERE @pe45 IS NULL;
SET @pe45 = COALESCE(@pe45, (SELECT id FROM personal WHERE nombres = 'Elsa Sulay' AND apellidos = 'Paz Sotero' ORDER BY id DESC LIMIT 1));

-- Equipo 61: PCS ASIGNADAS fila 63
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JNS3Y2', NULL, '57066', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 14, 'Microsoft Windows 10 Pro', 'EPAZS', 'E4:54:E8:98:FB:EC', '192.168.7.193', 'C0:B5:D7:93:E3:4D', @of14, @pe45, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 63]
Observación: PC2020-05
Último mantenimiento: 03/06/2026
Vida útil propuesta (meses): 4
Baja sugerida: 03/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62679)
Usuario de Windows: epazs
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14462'), (@eq, 2025, '1550');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, @pe45, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Secretaría General
SET @of15 = (SELECT id FROM oficinas WHERE nombre = 'Secretaría General' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Secretaría General', NULL, 'OFICINA' FROM DUAL WHERE @of15 IS NULL;
SET @of15 = COALESCE(@of15, (SELECT id FROM oficinas WHERE nombre = 'Secretaría General' AND padre_id <=> NULL LIMIT 1));

-- Oficina: Grados y Resoluciones
SET @of16 = (SELECT id FROM oficinas WHERE nombre = 'Grados y Resoluciones' AND padre_id <=> @of15 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of15, 'Grados y Resoluciones', NULL, 'OFICINA' FROM DUAL WHERE @of16 IS NULL;
SET @of16 = COALESCE(@of16, (SELECT id FROM oficinas WHERE nombre = 'Grados y Resoluciones' AND padre_id <=> @of15 LIMIT 1));

-- Personal: MILUSKA ROMERO CUBAS
SET @pe46 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MILUSKA ROMERO CUBAS' OR (nombres = 'Miluska' AND apellidos = 'Romero Cubas') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Miluska', 'Romero Cubas', @of16 FROM DUAL WHERE @pe46 IS NULL;
SET @pe46 = COALESCE(@pe46, (SELECT id FROM personal WHERE nombres = 'Miluska' AND apellidos = 'Romero Cubas' ORDER BY id DESC LIMIT 1));

-- Equipo 62: PCS ASIGNADAS fila 64
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 600 G1 SFF', 'MXL4150XWF', NULL, NULL, 'Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz', 8, 'SSD', 466, 'Microsoft Windows 10 Pro', 'PC2018-02', 'A0:48:1C:A1:DC:0C', '192.168.7.159', NULL, @of16, @pe46, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 64]
Último mantenimiento: 25/05/2026
Vida útil propuesta (meses): 7
Baja sugerida: 25/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A2F4)
Usuario de Windows: amamanio
Fecha BIOS: 17/12/2013
Núcleos/hilos CPU: 4/4
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 970821118', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13916'), (@eq, 2025, '1790');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of16, @pe46, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: FERNANDO CASTILLO ALATRISTA
SET @pe47 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'FERNANDO CASTILLO ALATRISTA' OR (nombres = 'Fernando' AND apellidos = 'Castillo Alatrista') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Fernando', 'Castillo Alatrista', @of16 FROM DUAL WHERE @pe47 IS NULL;
SET @pe47 = COALESCE(@pe47, (SELECT id FROM personal WHERE nombres = 'Fernando' AND apellidos = 'Castillo Alatrista' ORDER BY id DESC LIMIT 1));

-- Equipo 63: PCS ASIGNADAS fila 65
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '4LQ3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-81', 'E4:54:E8:CB:BA:DE', '192.168.7.195', '40:5B:D8:7C:1B:FB', @of16, @pe47, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 65]
Último mantenimiento: 25/05/2026
Vida útil propuesta (meses): 7
Baja sugerida: 25/12/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A39B)
Usuario de Windows: fcastilloa
Fecha BIOS: 08/01/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 350152454', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13178'), (@eq, 2025, '1799');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of16, @pe47, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: EDWIN ALFONSO RODRIGUEZ CASIMIRO
SET @pe48 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'EDWIN ALFONSO RODRIGUEZ CASIMIRO' OR (nombres = 'Edwin Alfonso' AND apellidos = 'Rodriguez Casimiro') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Edwin Alfonso', 'Rodriguez Casimiro', @of16 FROM DUAL WHERE @pe48 IS NULL;
SET @pe48 = COALESCE(@pe48, (SELECT id FROM personal WHERE nombres = 'Edwin Alfonso' AND apellidos = 'Rodriguez Casimiro' ORDER BY id DESC LIMIT 1));

-- Equipo 64: PCS ASIGNADAS fila 66
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'F5Q3813', NULL, '55567', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-60', 'E4:54:E8:CB:8F:C5', '192.168.8.24', '40:5B:D8:46:AD:0F', @of16, @pe48, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 66]
Último mantenimiento: 24/04/2026
Vida útil propuesta (meses): 7
Baja sugerida: 24/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D698FF)
Usuario de Windows: ichoyq
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1800720725', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13866'), (@eq, 2025, '1817');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of16, @pe48, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: LUIS OVIEDO CARRANZA
SET @pe49 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LUIS OVIEDO CARRANZA' OR (nombres = 'Luis' AND apellidos = 'Oviedo Carranza') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Luis', 'Oviedo Carranza', @of16 FROM DUAL WHERE @pe49 IS NULL;
SET @pe49 = COALESCE(@pe49, (SELECT id FROM personal WHERE nombres = 'Luis' AND apellidos = 'Oviedo Carranza' ORDER BY id DESC LIMIT 1));

-- Equipo 65: PCS ASIGNADAS fila 67
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM004Y2', NULL, '55568', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-34', 'E4:54:E8:9B:1F:22', NULL, 'EC:5C:68:B8:88:47', @of16, @pe49, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 67]
Último mantenimiento: 25/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 25/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D698F7)
Usuario de Windows: loviedo
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.163
Sophos: ACTIVADO
AnyDesk ID: 1086602033', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13852');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of16, @pe49, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 66: PCS ASIGNADAS fila 68
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WJY', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'SSD', 238, 'Microsoft Windows 10 Pro', 'PC2020-118', 'F8:0D:AC:13:36:3B', NULL, '40:74:E0:5E:19:51', @of16, @pe47, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 68]
Último mantenimiento: 25/05/2023
Vida útil propuesta (meses): 8
Baja sugerida: 25/01/2024
Antigüedad: 5 AÑOS
Disco sólido: Gigabyte (serie SN214508943488)
Usuario de Windows: soporte
Fecha BIOS: 23/08/2024
Núcleos/hilos CPU: 4/8
Modelo de disco: GIGABYTE GP-GSTFS31240GNTD
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14330'), (@eq, 2025, '1779');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of16, @pe47, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: GIOVANA CARLES TALLEDO
SET @pe50 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'GIOVANA CARLES TALLEDO' OR (nombres = 'Giovana' AND apellidos = 'Carles Talledo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Giovana', 'Carles Talledo', @of15 FROM DUAL WHERE @pe50 IS NULL;
SET @pe50 = COALESCE(@pe50, (SELECT id FROM personal WHERE nombres = 'Giovana' AND apellidos = 'Carles Talledo' ORDER BY id DESC LIMIT 1));

-- Equipo 67: PCS ASIGNADAS fila 69
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP Pro SFF 400 G9 Desktop PC', '4CE230CD0J', NULL, NULL, '12th Gen Intel(R) Core(TM) i7-12700', 16, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2023-01', '84:69:93:80:20:09', '192.168.7.126', '3C:55:76:48:0F:DD', @of15, @pe50, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 69]
Último mantenimiento: 08/04/2026
Vida útil propuesta (meses): 2
Baja sugerida: 08/06/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A2F5)
Usuario de Windows: rbaratam
Núcleos/hilos CPU: 12/20
Modelo de disco: WDC WD10EZEX-60WN4A2
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15412'), (@eq, 2025, '1731');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, @pe50, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: PAOLA MUÑOZ VELASQUEZ
SET @pe51 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PAOLA MUÑOZ VELASQUEZ' OR (nombres = 'Paola' AND apellidos = 'Muñoz Velasquez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Paola', 'Muñoz Velasquez', @of15 FROM DUAL WHERE @pe51 IS NULL;
SET @pe51 = COALESCE(@pe51, (SELECT id FROM personal WHERE nombres = 'Paola' AND apellidos = 'Muñoz Velasquez' ORDER BY id DESC LIMIT 1));

-- Equipo 68: PCS ASIGNADAS fila 70
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GJS', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-147', '10:E7:C6:B4:B7:76', '192.168.8.14', NULL, @of15, @pe51, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 70]
Observación: PC2019-08
Último mantenimiento: 16/03/2026
Vida útil propuesta (meses): 2
Baja sugerida: 16/05/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A170)
Usuario de Windows: SOPORTE
Fecha BIOS: 16/04/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1240317049', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '2464'), (@eq, 2025, '2315');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, @pe51, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: DARLYN LEON NUÑEZ
SET @pe52 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'DARLYN LEON NUÑEZ' OR (nombres = 'Darlyn' AND apellidos = 'Leon Nuñez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Darlyn', 'Leon Nuñez', @of15 FROM DUAL WHERE @pe52 IS NULL;
SET @pe52 = COALESCE(@pe52, (SELECT id FROM personal WHERE nombres = 'Darlyn' AND apellidos = 'Leon Nuñez' ORDER BY id DESC LIMIT 1));

-- Equipo 69: PCS ASIGNADAS fila 71
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '5KQ3813', NULL, '55549', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'SOPORTE-OTIC', 'E4:54:E8:CB:D2:0C', '192.168.7.65', '40:5B:D8:7B:5B:A9', @of15, @pe52, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 71]
Último mantenimiento: 21/01/2025
Vida útil propuesta (meses): 5
Baja sugerida: 21/06/2025
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62C66)
Usuario de Windows: jarauco
Fecha BIOS: 18/03/2022
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13117'), (@eq, 2025, '2529');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, @pe52, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MARIANELLA ELIZABETH COVEÑAS LEON
SET @pe53 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MARIANELLA ELIZABETH COVEÑAS LEON' OR (nombres = 'Marianella Elizabeth' AND apellidos = 'Coveñas Leon') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Marianella Elizabeth', 'Coveñas Leon', @of15 FROM DUAL WHERE @pe53 IS NULL;
SET @pe53 = COALESCE(@pe53, (SELECT id FROM personal WHERE nombres = 'Marianella Elizabeth' AND apellidos = 'Coveñas Leon' ORDER BY id DESC LIMIT 1));

-- Equipo 70: PCS ASIGNADAS fila 72
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'J5Q3813', NULL, '17656', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-55', 'E4:54:E8:CB:93:1D', '192.168.7.80', '40:5B:D8:46:AA:87', @of15, @pe53, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 72]
Último mantenimiento: 28/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 28/10/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6AC40)
Usuario de Windows: jsernaqued
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1708303946', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13886'), (@eq, 2025, '1437');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, @pe53, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Mesa de Partes
SET @of17 = (SELECT id FROM oficinas WHERE nombre = 'Mesa de Partes' AND padre_id <=> @of15 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of15, 'Mesa de Partes', NULL, 'OFICINA' FROM DUAL WHERE @of17 IS NULL;
SET @of17 = COALESCE(@of17, (SELECT id FROM oficinas WHERE nombre = 'Mesa de Partes' AND padre_id <=> @of15 LIMIT 1));

-- Personal: ROY POZO QUISPE
SET @pe54 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ROY POZO QUISPE' OR (nombres = 'Roy' AND apellidos = 'Pozo Quispe') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Roy', 'Pozo Quispe', @of17 FROM DUAL WHERE @pe54 IS NULL;
SET @pe54 = COALESCE(@pe54, (SELECT id FROM personal WHERE nombres = 'Roy' AND apellidos = 'Pozo Quispe' ORDER BY id DESC LIMIT 1));

-- Equipo 71: PCS ASIGNADAS fila 73
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JQV3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-43', 'E4:54:E8:98:FF:05', '192.168.7.68', NULL, @of17, @pe54, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 73]
Último mantenimiento: 08/05/2026
Vida útil propuesta (meses): 2
Baja sugerida: 08/07/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B76867B0E73)
Usuario de Windows: djimenezc
Fecha BIOS: 15/06/2020
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16303'), (@eq, 2025, '1824');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of17, @pe54, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ALEJANDRO MARIO HUMAN CCARI
SET @pe55 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ALEJANDRO MARIO HUMAN CCARI' OR (nombres = 'Alejandro Mario' AND apellidos = 'Human Ccari') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Alejandro Mario', 'Human Ccari', @of17 FROM DUAL WHERE @pe55 IS NULL;
SET @pe55 = COALESCE(@pe55, (SELECT id FROM personal WHERE nombres = 'Alejandro Mario' AND apellidos = 'Human Ccari' ORDER BY id DESC LIMIT 1));

-- Equipo 72: PCS ASIGNADAS fila 74
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CR5XNY2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-46', 'E4:54:E8:9B:23:7A', '192.168.7.154', NULL, @of17, @pe55, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 74]
Observación: FALTA DISCO SOLIDO
Último mantenimiento: 27/01/2026
Vida útil propuesta (meses): 2
Baja sugerida: 27/03/2026
Antigüedad: 5 AÑOS
Usuario de Windows: AHUMANC
Fecha BIOS: 27/01/2026
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16292'), (@eq, 2025, '1830');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of17, @pe55, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: ORRI
SET @of18 = (SELECT id FROM oficinas WHERE nombre = 'ORRI' AND padre_id <=> NULL LIMIT 1);
SET @of18 = COALESCE(@of18, (SELECT id FROM oficinas WHERE siglas = 'ORRI' AND padre_id <=> NULL LIMIT 1));
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'ORRI', 'ORRI', 'OFICINA' FROM DUAL WHERE @of18 IS NULL;
SET @of18 = COALESCE(@of18, (SELECT id FROM oficinas WHERE nombre = 'ORRI' AND padre_id <=> NULL LIMIT 1));

-- Personal: LUIS ALBERTO TUME SERPA
SET @pe56 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LUIS ALBERTO TUME SERPA' OR (nombres = 'Luis Alberto' AND apellidos = 'Tume Serpa') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Luis Alberto', 'Tume Serpa', @of18 FROM DUAL WHERE @pe56 IS NULL;
SET @pe56 = COALESCE(@pe56, (SELECT id FROM personal WHERE nombres = 'Luis Alberto' AND apellidos = 'Tume Serpa' ORDER BY id DESC LIMIT 1));

-- Equipo 73: PCS ASIGNADAS fila 75
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'F0Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-75', 'E4:54:E8:CB:BC:96', NULL, '40:5B:D8:A5:5F:81', @of18, @pe56, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 75]
Observación: FALTA DISCO SOLIDO
Último mantenimiento: 19/01/2026
Vida útil propuesta (meses): 2
Baja sugerida: 19/03/2026
Antigüedad: 5 AÑOS
Usuario de Windows: ltumes
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: WDC WD10EZEX-75WN4A1
IP Wi-Fi: 192.168.7.179
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15545'), (@eq, 2025, '2158');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, @pe56, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JAVIER TRELLES VIZQUERRA
SET @pe57 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JAVIER TRELLES VIZQUERRA' OR (nombres = 'Javier' AND apellidos = 'Trelles Vizquerra') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Javier', 'Trelles Vizquerra', @of18 FROM DUAL WHERE @pe57 IS NULL;
SET @pe57 = COALESCE(@pe57, (SELECT id FROM personal WHERE nombres = 'Javier' AND apellidos = 'Trelles Vizquerra' ORDER BY id DESC LIMIT 1));

-- Equipo 74: PCS ASIGNADAS fila 76
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 650 G4', '5CG94666VV', NULL, '53539', 'Intel(R) Core(TM) i7-8650U CPU @ 1.90GHz', 8, 'NVME', 932, NULL, 'PC2020-140', '00:68:EB:E8:30:99', NULL, '40:74:E0:5E:1A:A0', @of18, @pe57, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 76]
Último mantenimiento: 13/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 13/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686EAEC49)
Usuario de Windows: pcarmenv
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.7.177
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15580');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, @pe57, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: LUIS OCHOA MODESTO
SET @pe58 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LUIS OCHOA MODESTO' OR (nombres = 'Luis' AND apellidos = 'Ochoa Modesto') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Luis', 'Ochoa Modesto', @of18 FROM DUAL WHERE @pe58 IS NULL;
SET @pe58 = COALESCE(@pe58, (SELECT id FROM personal WHERE nombres = 'Luis' AND apellidos = 'Ochoa Modesto' ORDER BY id DESC LIMIT 1));

-- Equipo 75: PCS ASIGNADAS fila 77
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'ASUS', 'ASUS', NULL, NULL, NULL, '12th Gen Intel(R) Core(TM) i9-12900K', 32, 'SSD', 1908, 'Microsoft Windows 11 Pro', 'PC2023-134', '50:EB:F6:24:E7:2A', '192.168.8.226', '5C:E4:2A:4B:B4:28', @of18, @pe58, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 77]
Último mantenimiento: 14/01/2026
Vida útil propuesta (meses): 18
Baja sugerida: 14/07/2027
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 0000_0000_0000_0000_0026_B768_6348_2AA5)
Usuario de Windows: marketing-orri
Núcleos/hilos CPU: 16/24
Modelo de disco: KINGSTON SKC3000D2048G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15567');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, @pe58, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JUDITH MARY ARENAS PEREZ
SET @pe59 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JUDITH MARY ARENAS PEREZ' OR (nombres = 'Judith Mary' AND apellidos = 'Arenas Perez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Judith Mary', 'Arenas Perez', @of18 FROM DUAL WHERE @pe59 IS NULL;
SET @pe59 = COALESCE(@pe59, (SELECT id FROM personal WHERE nombres = 'Judith Mary' AND apellidos = 'Arenas Perez' ORDER BY id DESC LIMIT 1));

-- Equipo 76: PCS ASIGNADAS fila 78
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JJX3Y2', NULL, '56936', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 11 Pro', 'PC2020-19', 'E4:54:E8:98:FE:9F', NULL, 'C0:B5:D7:93:86:D1', @of18, @pe59, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 78]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 02/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A822)
Usuario de Windows: jarenasp
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.9.25
Sophos: ACTIVADO
AnyDesk ID: 1935309341', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15566'), (@eq, 2025, '2133');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, @pe59, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Captación
SET @of19 = (SELECT id FROM oficinas WHERE nombre = 'Captación' AND padre_id <=> @of18 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of18, 'Captación', NULL, 'OFICINA' FROM DUAL WHERE @of19 IS NULL;
SET @of19 = COALESCE(@of19, (SELECT id FROM oficinas WHERE nombre = 'Captación' AND padre_id <=> @of18 LIMIT 1));

-- Personal: PEDRO PABLO PONCE RODRIGUEZ
SET @pe60 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PEDRO PABLO PONCE RODRIGUEZ' OR (nombres = 'Pedro Pablo' AND apellidos = 'Ponce Rodriguez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Pedro Pablo', 'Ponce Rodriguez', @of19 FROM DUAL WHERE @pe60 IS NULL;
SET @pe60 = COALESCE(@pe60, (SELECT id FROM personal WHERE nombres = 'Pedro Pablo' AND apellidos = 'Ponce Rodriguez' ORDER BY id DESC LIMIT 1));

-- Equipo 77: PCS ASIGNADAS fila 79
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLQ34Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', NULL, 'E4:54:E8:9B:1C:3F', NULL, 'EC:5C:68:B6:D7:DF', @of19, @pe60, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 79]
Último mantenimiento: 24/03/2026
Vida útil propuesta (meses): 7
Baja sugerida: 24/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C6295F)
Usuario de Windows: hquispem
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.122
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13686'), (@eq, 2025, '0839');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of19, @pe60, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: FERNANDO VICENTE SERRA RIOS
SET @pe61 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'FERNANDO VICENTE SERRA RIOS' OR (nombres = 'Fernando Vicente' AND apellidos = 'Serra Rios') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Fernando Vicente', 'Serra Rios', @of19 FROM DUAL WHERE @pe61 IS NULL;
SET @pe61 = COALESCE(@pe61, (SELECT id FROM personal WHERE nombres = 'Fernando Vicente' AND apellidos = 'Serra Rios' ORDER BY id DESC LIMIT 1));

-- Equipo 78: PCS ASIGNADAS fila 80
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JHT3Y2', NULL, '56933', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 11 Pro', 'PC-202024', 'E4:54:E8:98:FF:3B', '192.168.8.94', 'C0:B5:D7:93:7B:E9', @of19, @pe61, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 80]
Observación: PC2020-48
Último mantenimiento: 21/04/2026
Vida útil propuesta (meses): 7
Baja sugerida: 21/11/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6AC41)
Usuario de Windows: fserrar
Fecha BIOS: 25/03/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1523034412', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15603'), (@eq, 2025, '2186');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of19, @pe61, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: OPP
SET @of20 = (SELECT id FROM oficinas WHERE nombre = 'OPP' AND padre_id <=> NULL LIMIT 1);
SET @of20 = COALESCE(@of20, (SELECT id FROM oficinas WHERE siglas = 'OPP' AND padre_id <=> NULL LIMIT 1));
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'OPP', 'OPP', 'OFICINA' FROM DUAL WHERE @of20 IS NULL;
SET @of20 = COALESCE(@of20, (SELECT id FROM oficinas WHERE nombre = 'OPP' AND padre_id <=> NULL LIMIT 1));

-- Personal: JOSE EDUARDO CAVANI RIOS
SET @pe62 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSE EDUARDO CAVANI RIOS' OR (nombres = 'Jose Eduardo' AND apellidos = 'Cavani Rios') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jose Eduardo', 'Cavani Rios', @of20 FROM DUAL WHERE @pe62 IS NULL;
SET @pe62 = COALESCE(@pe62, (SELECT id FROM personal WHERE nombres = 'Jose Eduardo' AND apellidos = 'Cavani Rios' ORDER BY id DESC LIMIT 1));

-- Equipo 79: PCS ASIGNADAS fila 81
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '55Q3813', NULL, '56907', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'JCAVANIR', 'E4:54:E8:CB:8F:C4', NULL, '40:5B:D8:46:AC:39', @of20, @pe62, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 81]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 2
Baja sugerida: 01/08/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C63469)
Usuario de Windows: jcavanir
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.7
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15151'), (@eq, 2025, '2101');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of20, @pe62, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: GEORGINIO ROJAS JIMENEZ
SET @pe63 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'GEORGINIO ROJAS JIMENEZ' OR (nombres = 'Georginio' AND apellidos = 'Rojas Jimenez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Georginio', 'Rojas Jimenez', @of20 FROM DUAL WHERE @pe63 IS NULL;
SET @pe63 = COALESCE(@pe63, (SELECT id FROM personal WHERE nombres = 'Georginio' AND apellidos = 'Rojas Jimenez' ORDER BY id DESC LIMIT 1));

-- Equipo 80: PCS ASIGNADAS fila 82
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WBY', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 238, 'Microsoft Windows 10 Pro', 'PC2020-121', 'F8:0D:AC:13:37:48', NULL, NULL, @of20, @pe63, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 82]
Último mantenimiento: 08/03/2026
Vida útil propuesta (meses): 6
Baja sugerida: 08/09/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON M2 (serie 0000_0000_0000_0000_0026_B768_6EAE_C6C5)
Usuario de Windows: rlaurenteh
Núcleos/hilos CPU: 4/8
Modelo de disco: TEAM TM8FP6256G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2090');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of20, @pe63, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: LAURA LOPEZ ROJAS
SET @pe64 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LAURA LOPEZ ROJAS' OR (nombres = 'Laura' AND apellidos = 'Lopez Rojas') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Laura', 'Lopez Rojas', @of20 FROM DUAL WHERE @pe64 IS NULL;
SET @pe64 = COALESCE(@pe64, (SELECT id FROM personal WHERE nombres = 'Laura' AND apellidos = 'Lopez Rojas' ORDER BY id DESC LIMIT 1));

-- Equipo 81: PCS ASIGNADAS fila 83
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'JJQ3813', NULL, '56920', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'LLOPEZR', 'E4:54:E8:CB:91:D3', NULL, '40:5B:D8:7C:1B:FD', @of20, @pe64, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 83]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 2
Baja sugerida: 01/08/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62A43)
Usuario de Windows: llopezr
Fecha BIOS: 03/12/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
IP LAN 192.168.8.14 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15157'), (@eq, 2025, '2112');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of20, @pe64, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JOHANA IRMA ORE PIZARRO
SET @pe65 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOHANA IRMA ORE PIZARRO' OR (nombres = 'Johana Irma' AND apellidos = 'Ore Pizarro') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Johana Irma', 'Ore Pizarro', @of20 FROM DUAL WHERE @pe65 IS NULL;
SET @pe65 = COALESCE(@pe65, (SELECT id FROM personal WHERE nombres = 'Johana Irma' AND apellidos = 'Ore Pizarro' ORDER BY id DESC LIMIT 1));

-- Equipo 82: PCS ASIGNADAS fila 84
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM534Y2', NULL, '56922', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-14', 'E4:54:E8:9B:1C:1C', '192.168.7.248', 'EC:5C:68:B8:27:4B', @of20, @pe65, 'OPERATIVO', 'MALO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 84]
Observación: PC2020-14
Último mantenimiento: 27/01/2026
Vida útil propuesta (meses): 2
Baja sugerida: 27/03/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62956)
Usuario de Windows: jorep
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15143'), (@eq, 2025, '2096');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of20, @pe65, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Oficina de Calidad
SET @of21 = (SELECT id FROM oficinas WHERE nombre = 'Oficina de Calidad' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Oficina de Calidad', NULL, 'OFICINA' FROM DUAL WHERE @of21 IS NULL;
SET @of21 = COALESCE(@of21, (SELECT id FROM oficinas WHERE nombre = 'Oficina de Calidad' AND padre_id <=> NULL LIMIT 1));

-- Personal: CESAR SEGUNDO LLONTOP SEBASTIANI
SET @pe66 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CESAR SEGUNDO LLONTOP SEBASTIANI' OR (nombres = 'Cesar Segundo' AND apellidos = 'Llontop Sebastiani') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Cesar Segundo', 'Llontop Sebastiani', @of21 FROM DUAL WHERE @pe66 IS NULL;
SET @pe66 = COALESCE(@pe66, (SELECT id FROM personal WHERE nombres = 'Cesar Segundo' AND apellidos = 'Llontop Sebastiani' ORDER BY id DESC LIMIT 1));

-- Equipo 83: PCS ASIGNADAS fila 85
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 650 G4', '5CG94666VP', NULL, NULL, 'Intel(R) Core(TM) i7-8650U CPU @ 1.90GHz', 8, 'HDD', 477, NULL, 'DESKTOP-QLVL9SI', '00:68:EB:E8:30:98', '192.168.7.151', NULL, @of21, @pe66, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 85]
Último mantenimiento: 27/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 27/11/2026
Antigüedad: 5 AÑOS
Disco sólido: Western Digital M.2 (serie WD PC SN530 NVMe SSD)
Usuario de Windows: s/u
Núcleos/hilos CPU: 4/8
Modelo de disco: WDC WD10SPZX-60Z10T0
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of21, @pe66, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 84: PCS ASIGNADAS fila 86
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0384NRT', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 238, NULL, NULL, NULL, NULL, NULL, @of21, @pe66, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 86]
Último mantenimiento: 27/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 27/01/2027
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 0000_0006_0000_0000_3A5A_2702_3000_0F9C)
Núcleos/hilos CPU: 4/8
Modelo de disco: TEAM TM8FP6256G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14395'), (@eq, 2025, '2070');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of21, @pe66, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JEANINE EDELMIRA AGUIRRE ZUNIGA
SET @pe67 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JEANINE EDELMIRA AGUIRRE ZUNIGA' OR (nombres = 'Jeanine Edelmira' AND apellidos = 'Aguirre Zuniga') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jeanine Edelmira', 'Aguirre Zuniga', @of21 FROM DUAL WHERE @pe67 IS NULL;
SET @pe67 = COALESCE(@pe67, (SELECT id FROM personal WHERE nombres = 'Jeanine Edelmira' AND apellidos = 'Aguirre Zuniga' ORDER BY id DESC LIMIT 1));

-- Equipo 85: PCS ASIGNADAS fila 87
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '7KQ3813', NULL, '55565', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-80', 'E4:54:E8:CB:D3:15', '192.168.7.95', '40:5B:D8:7B:61:55', @of21, @pe67, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 87]
Último mantenimiento: 27/05/2026
Vida útil propuesta (meses): 4
Baja sugerida: 27/09/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A735)
Usuario de Windows: jaguirrez
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1428992171', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15513');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of21, @pe67, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: SUGHEIS YANIDHET CUADROS NEYRA
SET @pe68 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'SUGHEIS YANIDHET CUADROS NEYRA' OR (nombres = 'Sugheis Yanidhet' AND apellidos = 'Cuadros Neyra') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Sugheis Yanidhet', 'Cuadros Neyra', @of21 FROM DUAL WHERE @pe68 IS NULL;
SET @pe68 = COALESCE(@pe68, (SELECT id FROM personal WHERE nombres = 'Sugheis Yanidhet' AND apellidos = 'Cuadros Neyra' ORDER BY id DESC LIMIT 1));

-- Equipo 86: PCS ASIGNADAS fila 88
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM474Y2', NULL, '55566', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'SCUADROSN', 'E4:54:E8:9B:1A:80', '192.168.8.30', 'EC:5C:68:B6:D7:ED', @of21, @pe68, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 88]
Último mantenimiento: 27/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 27/11/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C625DA)
Usuario de Windows: scuadrosn
Fecha BIOS: 15/06/2020
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15505');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of21, @pe68, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dirección General
SET @of22 = (SELECT id FROM oficinas WHERE nombre = 'Dirección General' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Dirección General', NULL, 'DIRECCION' FROM DUAL WHERE @of22 IS NULL;
SET @of22 = COALESCE(@of22, (SELECT id FROM oficinas WHERE nombre = 'Dirección General' AND padre_id <=> NULL LIMIT 1));

-- Personal: PAOLA CARMEN VILLAFUERTE
SET @pe69 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PAOLA CARMEN VILLAFUERTE' OR (nombres = 'Paola' AND apellidos = 'Carmen Villafuerte') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Paola', 'Carmen Villafuerte', @of22 FROM DUAL WHERE @pe69 IS NULL;
SET @pe69 = COALESCE(@pe69, (SELECT id FROM personal WHERE nombres = 'Paola' AND apellidos = 'Carmen Villafuerte' ORDER BY id DESC LIMIT 1));

-- Equipo 87: PCS ASIGNADAS fila 89
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G8', NULL, NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-134', NULL, NULL, NULL, @of22, @pe69, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 89]
Último mantenimiento: 15/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 15/12/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie WD-WXC2A60L8PUE)
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14022');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of22, @pe69, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 88: PCS ASIGNADAS fila 90
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '31Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, NULL, 'MKUANG', 'E4:54:E8:CB:BA:26', '192.168.7.202', '40:5B:D8:A5:66:03', @of22, @pe69, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 90]
Último mantenimiento: 06/04/2026
Vida útil propuesta (meses): 4
Baja sugerida: 06/08/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62695)
Usuario de Windows: mkuang
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15378'), (@eq, 2025, '1669');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of22, @pe69, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Instituto General Marín
SET @of23 = (SELECT id FROM oficinas WHERE nombre = 'Instituto General Marín' AND padre_id <=> NULL LIMIT 1);
SET @of23 = COALESCE(@of23, (SELECT id FROM oficinas WHERE siglas = 'IIGMA' AND padre_id <=> NULL LIMIT 1));
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Instituto General Marín', 'IIGMA', 'OFICINA' FROM DUAL WHERE @of23 IS NULL;
SET @of23 = COALESCE(@of23, (SELECT id FROM oficinas WHERE nombre = 'Instituto General Marín' AND padre_id <=> NULL LIMIT 1));

-- Personal: JUAN FERNANDO ORMACHEA MONTES
SET @pe70 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JUAN FERNANDO ORMACHEA MONTES' OR (nombres = 'Juan Fernando' AND apellidos = 'Ormachea Montes') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Juan Fernando', 'Ormachea Montes', @of23 FROM DUAL WHERE @pe70 IS NULL;
SET @pe70 = COALESCE(@pe70, (SELECT id FROM personal WHERE nombres = 'Juan Fernando' AND apellidos = 'Ormachea Montes' ORDER BY id DESC LIMIT 1));

-- Equipo 89: PCS ASIGNADAS fila 91
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 650 G4', '5CG94666VT', NULL, NULL, 'Intel(R) Core(TM) i7-8650U CPU @ 1.90GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC-JEFE-OTIC', NULL, NULL, '54:E7:59:1A:47:00', @of23, @pe70, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 91]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 02/12/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON M2 (serie 0000_0000_0000_0000_0026_B778_582A_E055)
Usuario de Windows: OTIC
Fecha BIOS: 18/07/2019
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.10.250', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14523');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe70, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JUAN SALVADOR
SET @pe71 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JUAN SALVADOR' OR (nombres = 'Juan' AND apellidos = 'Salvador') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Juan', 'Salvador', @of23 FROM DUAL WHERE @pe71 IS NULL;
SET @pe71 = COALESCE(@pe71, (SELECT id FROM personal WHERE nombres = 'Juan' AND apellidos = 'Salvador' ORDER BY id DESC LIMIT 1));

-- Equipo 90: PCS ASIGNADAS fila 92
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM034Y2', NULL, '57153', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-31', 'E4:54:E8:9B:1C:2F', NULL, 'EC:5C:68:B8:8D:6D', @of23, @pe71, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 92]
Último mantenimiento: 26/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 26/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69EB8)
Usuario de Windows: pmunozv
Fecha BIOS: 13/07/2021
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.195
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15633'), (@eq, 2025, '1966');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe71, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: KELLY FIGUEROA ALMONACID
SET @pe72 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'KELLY FIGUEROA ALMONACID' OR (nombres = 'Kelly' AND apellidos = 'Figueroa Almonacid') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Kelly', 'Figueroa Almonacid', @of23 FROM DUAL WHERE @pe72 IS NULL;
SET @pe72 = COALESCE(@pe72, (SELECT id FROM personal WHERE nombres = 'Kelly' AND apellidos = 'Figueroa Almonacid' ORDER BY id DESC LIMIT 1));

-- Equipo 91: PCS ASIGNADAS fila 93
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8J6R3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-32', 'E4:54:E8:98:FE:E9', '192.168.8.41', 'C0:B5:D7:93:7E:C3', @of23, @pe72, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 93]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 7
Baja sugerida: 01/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69EC5)
Usuario de Windows: kfigueroaa
Fecha BIOS: 25/03/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 29
AnyDesk ID: 1558650674', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15644'), (@eq, 2025, '1982');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe72, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 92: PCS ASIGNADAS fila 94
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JRX3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-84', 'C0:B5:D7:93:7E:CD', NULL, NULL, @of23, @pe70, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 94]
Último mantenimiento: 22/01/2026
Vida útil propuesta (meses): 8
Baja sugerida: 22/09/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0ED8)
Usuario de Windows: jormacheam
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
IP LAN 192.168.8.24 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15536'), (@eq, 2025, '2398');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe70, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ROBERTO ALONSO PINZÁS FACUNDO
SET @pe73 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ROBERTO ALONSO PINZÁS FACUNDO' OR (nombres = 'Roberto Alonso' AND apellidos = 'Pinzás Facundo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Roberto Alonso', 'Pinzás Facundo', @of23 FROM DUAL WHERE @pe73 IS NULL;
SET @pe73 = COALESCE(@pe73, (SELECT id FROM personal WHERE nombres = 'Roberto Alonso' AND apellidos = 'Pinzás Facundo' ORDER BY id DESC LIMIT 1));

-- Equipo 93: PCS ASIGNADAS fila 95
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CRCWNY2', NULL, '57151', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-25', 'E4:54:E8:9B:0A:B5', NULL, 'C0:B5:D7:A3:84:CD', @of23, @pe73, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 95]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 8
Baja sugerida: 01/02/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6AC3E)
Usuario de Windows: ahuamanm
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.167
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 29
AnyDesk ID: 1693175123', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15660'), (@eq, 2025, '1999');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe73, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ALEXANDRA MOLINA DIMITRIJEVICH
SET @pe74 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ALEXANDRA MOLINA DIMITRIJEVICH' OR (nombres = 'Alexandra' AND apellidos = 'Molina Dimitrijevich') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Alexandra', 'Molina Dimitrijevich', @of23 FROM DUAL WHERE @pe74 IS NULL;
SET @pe74 = COALESCE(@pe74, (SELECT id FROM personal WHERE nombres = 'Alexandra' AND apellidos = 'Molina Dimitrijevich' ORDER BY id DESC LIMIT 1));

-- Equipo 94: PCS ASIGNADAS fila 96
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JPT3Y2', NULL, '57152', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC-202030', 'E4:54:E8:98:FE:FE', NULL, 'C0:B5:D7:93:7E:EF', @of23, @pe74, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 96]
Último mantenimiento: 26/05/2026
Vida útil propuesta (meses): 8
Baja sugerida: 26/01/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69EBE)
Usuario de Windows: fzegarral
Fecha BIOS: 25/03/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.8.55
Sophos: ACTIVADO
AnyDesk ID: 1488113357', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15690'), (@eq, 2025, '1992');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe74, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ALISSON LUISA CORDERO QUISPE
SET @pe75 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ALISSON LUISA CORDERO QUISPE' OR (nombres = 'Alisson Luisa' AND apellidos = 'Cordero Quispe') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Alisson Luisa', 'Cordero Quispe', @of23 FROM DUAL WHERE @pe75 IS NULL;
SET @pe75 = COALESCE(@pe75, (SELECT id FROM personal WHERE nombres = 'Alisson Luisa' AND apellidos = 'Cordero Quispe' ORDER BY id DESC LIMIT 1));

-- Equipo 95: PCS ASIGNADAS fila 97
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, 'PC2020-168', NULL, NULL, NULL, @of23, @pe75, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 97]
Último mantenimiento: 26/05/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie KINGSTON SA400S37960G)', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15625'), (@eq, 2025, '2011');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe75, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: MARCO ANTONIO MIRANDA VALDEZ
SET @pe76 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MARCO ANTONIO MIRANDA VALDEZ' OR (nombres = 'Marco Antonio' AND apellidos = 'Miranda Valdez') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Marco Antonio', 'Miranda Valdez', @of23 FROM DUAL WHERE @pe76 IS NULL;
SET @pe76 = COALESCE(@pe76, (SELECT id FROM personal WHERE nombres = 'Marco Antonio' AND apellidos = 'Miranda Valdez' ORDER BY id DESC LIMIT 1));

-- Equipo 96: PCS ASIGNADAS fila 98
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8J7V3Y2', NULL, '57150', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-33', 'E4:54:E8:98:FF:0F', '192.168.7.225', 'C0:B5:D7:93:E3:49', @of23, @pe76, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 98]
Último mantenimiento: 01/06/2026
Vida útil propuesta (meses): 8
Baja sugerida: 01/02/2027
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D698F6)
Usuario de Windows: elonkanp
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
Licencia Office 365: LICENCIA 32
AnyDesk ID: 1066500022', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15674'), (@eq, 2025, '1959');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe76, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 97: PCS ASIGNADAS fila 99
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, NULL, 'SSD', 932, NULL, NULL, NULL, NULL, NULL, @of23, @pe75, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 99]
Último mantenimiento: 02/06/2026
Vida útil propuesta (meses): 5
Baja sugerida: 02/11/2026
Antigüedad: 5 AÑOS
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
Hostname PC2020-168 repetido en el Excel: no se guardó.
Código 2024 15625 repetido o no válido: no se guardó.
Código 2025 2011 repetido o no válido: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, @pe75, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Responsabilidad Social
SET @of24 = (SELECT id FROM oficinas WHERE nombre = 'Responsabilidad Social' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Responsabilidad Social', NULL, 'OFICINA' FROM DUAL WHERE @of24 IS NULL;
SET @of24 = COALESCE(@of24, (SELECT id FROM oficinas WHERE nombre = 'Responsabilidad Social' AND padre_id <=> NULL LIMIT 1));

-- Personal: MARTIN HEREDIA OCHARAN
SET @pe77 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MARTIN HEREDIA OCHARAN' OR (nombres = 'Martin' AND apellidos = 'Heredia Ocharan') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Martin', 'Heredia Ocharan', @of24 FROM DUAL WHERE @pe77 IS NULL;
SET @pe77 = COALESCE(@pe77, (SELECT id FROM personal WHERE nombres = 'Martin' AND apellidos = 'Heredia Ocharan' ORDER BY id DESC LIMIT 1));

-- Equipo 98: PCS ASIGNADAS fila 100
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WFT', NULL, '55762', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-98', 'F8:0D:AC:13:37:EB', '192.168.7.76', 'AC:12:03:8A:C0:23', @of24, @pe77, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 100]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 20/12/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97AF5)
Usuario de Windows: jefe1.logistica
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16489');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of24, @pe77, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 99: PCS ASIGNADAS fila 101
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JCV3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-18', 'E4:54:E8:98:FE:85', '192.168.8.36', 'C0:B5:D7:93:86:C5', @of24, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 101]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 20/10/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69830)
Usuario de Windows: MHEREDIAO
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1748351502', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13421');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of24, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Asesoría Jurídica
SET @of25 = (SELECT id FROM oficinas WHERE nombre = 'Asesoría Jurídica' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Asesoría Jurídica', NULL, 'OFICINA' FROM DUAL WHERE @of25 IS NULL;
SET @of25 = COALESCE(@of25, (SELECT id FROM oficinas WHERE nombre = 'Asesoría Jurídica' AND padre_id <=> NULL LIMIT 1));

-- Personal: EVELYN QUINTO OSORIO
SET @pe78 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'EVELYN QUINTO OSORIO' OR (nombres = 'Evelyn' AND apellidos = 'Quinto Osorio') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Evelyn', 'Quinto Osorio', @of25 FROM DUAL WHERE @pe78 IS NULL;
SET @pe78 = COALESCE(@pe78, (SELECT id FROM personal WHERE nombres = 'Evelyn' AND apellidos = 'Quinto Osorio' ORDER BY id DESC LIMIT 1));

-- Equipo 100: PCS ASIGNADAS fila 102
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'H2QHT13', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 932, 'Microsoft Windows 11 Pro', 'PC2020-65', 'E4:54:E8:D1:13:C2', NULL, 'E8:6F:38:45:BD:4F', @of25, @pe78, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 102]
Último mantenimiento: 27/04/2026
Vida útil propuesta (meses): 8
Baja sugerida: 27/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A2FC)
Usuario de Windows: equintoo
Fecha BIOS: 08/06/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.9.64
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13751'), (@eq, 2025, '1904');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of25, @pe78, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: PEDRO FLORIAN FAJARDO
SET @pe79 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'PEDRO FLORIAN FAJARDO' OR (nombres = 'Pedro' AND apellidos = 'Florian Fajardo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Pedro', 'Florian Fajardo', @of25 FROM DUAL WHERE @pe79 IS NULL;
SET @pe79 = COALESCE(@pe79, (SELECT id FROM personal WHERE nombres = 'Pedro' AND apellidos = 'Florian Fajardo' ORDER BY id DESC LIMIT 1));

-- Equipo 101: PCS ASIGNADAS fila 103
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JMR3Y2', NULL, '55560', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-16', 'E4:54:E8:98:FC:65', '192.168.11.91', 'C0:B5:D7:93:E1:57', @of25, @pe79, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 103]
Último mantenimiento: 27/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 27/10/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D69EC9)
Usuario de Windows: pflorianf
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.96
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13740'), (@eq, 2025, '1886');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of25, @pe79, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Oficina de Tecnologías de la Información y Comunicación
SET @of26 = (SELECT id FROM oficinas WHERE nombre = 'Oficina de Tecnologías de la Información y Comunicación' AND padre_id <=> NULL LIMIT 1);
SET @of26 = COALESCE(@of26, (SELECT id FROM oficinas WHERE siglas = 'OTIC' AND padre_id <=> NULL LIMIT 1));
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Oficina de Tecnologías de la Información y Comunicación', 'OTIC', 'OFICINA' FROM DUAL WHERE @of26 IS NULL;
SET @of26 = COALESCE(@of26, (SELECT id FROM oficinas WHERE nombre = 'Oficina de Tecnologías de la Información y Comunicación' AND padre_id <=> NULL LIMIT 1));

-- Oficina: Jefatura
SET @of27 = (SELECT id FROM oficinas WHERE nombre = 'Jefatura' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Jefatura', NULL, 'OFICINA' FROM DUAL WHERE @of27 IS NULL;
SET @of27 = COALESCE(@of27, (SELECT id FROM oficinas WHERE nombre = 'Jefatura' AND padre_id <=> @of26 LIMIT 1));

-- Personal: MARIANELA VILLAR
SET @pe80 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'MARIANELA VILLAR' OR (nombres = 'Marianela' AND apellidos = 'Villar') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Marianela', 'Villar', @of27 FROM DUAL WHERE @pe80 IS NULL;
SET @pe80 = COALESCE(@pe80, (SELECT id FROM personal WHERE nombres = 'Marianela' AND apellidos = 'Villar' ORDER BY id DESC LIMIT 1));

-- Equipo 102: PCS ASIGNADAS fila 104
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '96Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'MVILLARR', 'E4:54:E8:CB:DB:9D', '192.168.8.46', '40:5B:D8:46:05:19', @of27, @pe80, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 104]
Observación: PC2020-59
Último mantenimiento: 23/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 23/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62CC1)
Usuario de Windows: mvillarr
Fecha BIOS: 25/09/2019
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14372'), (@eq, 2025, '2340');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of27, @pe80, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: ALEJANDRO
SET @pe81 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'ALEJANDRO' OR (nombres = 'Alejandro' AND apellidos = '-') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Alejandro', '-', @of27 FROM DUAL WHERE @pe81 IS NULL;
SET @pe81 = COALESCE(@pe81, (SELECT id FROM personal WHERE nombres = 'Alejandro' AND apellidos = '-' ORDER BY id DESC LIMIT 1));

-- Equipo 103: PCS ASIGNADAS fila 105
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WDR', NULL, '53543', 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-96', 'F8:0D:AC:13:37:BF', NULL, 'AC:12:03:8A:A2:AA', @of27, @pe81, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 105]
Último mantenimiento: 04/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 04/12/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON M2 (serie 50026B7686E97F31)
Usuario de Windows: aramirezq
Fecha BIOS: 23/08/2024
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.7.68
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14316');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of27, @pe81, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Infraestructura
SET @of28 = (SELECT id FROM oficinas WHERE nombre = 'Infraestructura' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Infraestructura', NULL, 'OFICINA' FROM DUAL WHERE @of28 IS NULL;
SET @of28 = COALESCE(@of28, (SELECT id FROM oficinas WHERE nombre = 'Infraestructura' AND padre_id <=> @of26 LIMIT 1));

-- Personal: CARLOS YSIQUE
SET @pe82 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'CARLOS YSIQUE' OR (nombres = 'Carlos' AND apellidos = 'Ysique') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Carlos', 'Ysique', @of28 FROM DUAL WHERE @pe82 IS NULL;
SET @pe82 = COALESCE(@pe82, (SELECT id FROM personal WHERE nombres = 'Carlos' AND apellidos = 'Ysique' ORDER BY id DESC LIMIT 1));

-- Equipo 104: PCS ASIGNADAS fila 106
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'FKQ3813', NULL, '55556', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 11 Pro', 'DESARROLLO-TIC', 'E4:54:E8:CB:BA:21', '169.254.118.58', '40:5B:D8:7B:61:01', @of28, @pe82, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 106]
Último mantenimiento: 11/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 11/10/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C62C65)
Usuario de Windows: desarrollo-tic
Fecha BIOS: 08/01/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14366'), (@eq, 2025, '2371');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of28, @pe82, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 105: PCS ASIGNADAS fila 107
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CD0386WTC', NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, NULL, NULL, NULL, NULL, @of28, @pe82, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 107]
Vida útil propuesta (meses): 7
Baja sugerida: 212
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 000_0006_0000_0000_3A5A_2702_3000_1668)
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of28, @pe82, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Telemática
SET @of29 = (SELECT id FROM oficinas WHERE nombre = 'Telemática' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Telemática', NULL, 'OFICINA' FROM DUAL WHERE @of29 IS NULL;
SET @of29 = COALESCE(@of29, (SELECT id FROM oficinas WHERE nombre = 'Telemática' AND padre_id <=> @of26 LIMIT 1));

-- Personal: RUDY ANGULO
SET @pe83 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'RUDY ANGULO' OR (nombres = 'Rudy' AND apellidos = 'Angulo') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Rudy', 'Angulo', @of29 FROM DUAL WHERE @pe83 IS NULL;
SET @pe83 = COALESCE(@pe83, (SELECT id FROM personal WHERE nombres = 'Rudy' AND apellidos = 'Angulo' ORDER BY id DESC LIMIT 1));

-- Equipo 106: PCS ASIGNADAS fila 108
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JPV3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-02', 'C0:B5:D7:93:7E:FB', '192.168.7.241', NULL, @of29, @pe83, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 108]
Último mantenimiento: 02/03/2026
Vida útil propuesta (meses): 4
Baja sugerida: 02/07/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B76867B0DDA)
Usuario de Windows: jalberto
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13124'), (@eq, 2025, '2523');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of29, @pe83, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Desarrollo
SET @of30 = (SELECT id FROM oficinas WHERE nombre = 'Desarrollo' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Desarrollo', NULL, 'OFICINA' FROM DUAL WHERE @of30 IS NULL;
SET @of30 = COALESCE(@of30, (SELECT id FROM oficinas WHERE nombre = 'Desarrollo' AND padre_id <=> @of26 LIMIT 1));

-- Personal: LUIS FERNANDO AURIS RUIZ
SET @pe84 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'LUIS FERNANDO AURIS RUIZ' OR (nombres = 'Luis Fernando' AND apellidos = 'Auris Ruiz') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Luis Fernando', 'Auris Ruiz', @of30 FROM DUAL WHERE @pe84 IS NULL;
SET @pe84 = COALESCE(@pe84, (SELECT id FROM personal WHERE nombres = 'Luis Fernando' AND apellidos = 'Auris Ruiz' ORDER BY id DESC LIMIT 1));

-- Equipo 107: PCS ASIGNADAS fila 109
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JDR3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PROGRAMADOR3', 'E4:54:E8:98:FF:4F', '192.168.9.135', 'C0:B5:D7:93:E0:C9', @of30, @pe84, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 109]
Observación: PC2020-28
Último mantenimiento: 24/04/2026
Vida útil propuesta (meses): 4
Baja sugerida: 24/08/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE98D)
Usuario de Windows: programador3
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13162'), (@eq, 2025, '2506');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of30, @pe84, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: Danixa Ledesma Pacco
SET @pe85 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'Danixa Ledesma Pacco' OR (nombres = 'Danixa' AND apellidos = 'Ledesma Pacco') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Danixa', 'Ledesma Pacco', @of29 FROM DUAL WHERE @pe85 IS NULL;
SET @pe85 = COALESCE(@pe85, (SELECT id FROM personal WHERE nombres = 'Danixa' AND apellidos = 'Ledesma Pacco' ORDER BY id DESC LIMIT 1));

-- Equipo 108: PCS ASIGNADAS fila 110
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '3KQ3813', NULL, '55561', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-57', 'E4:54:E8:CB:92:A2', NULL, '40:5B:D8:7B:5B:65', @of29, @pe85, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 110]
Último mantenimiento: 31/03/2026
Vida útil propuesta (meses): 4
Baja sugerida: 31/07/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6982A)
Usuario de Windows: dledesmap
Fecha BIOS: 19/09/2025
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.9.247
Sophos: ACTIVADO
AnyDesk ID: 1369525896', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14398'), (@eq, 2025, '2304');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of29, @pe85, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Data Center
SET @of31 = (SELECT id FROM oficinas WHERE nombre = 'Data Center' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Data Center', NULL, 'OFICINA' FROM DUAL WHERE @of31 IS NULL;
SET @of31 = COALESCE(@of31, (SELECT id FROM oficinas WHERE nombre = 'Data Center' AND padre_id <=> @of26 LIMIT 1));

-- Equipo 109: PCS ASIGNADAS fila 111
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WYZ', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-113', 'F8:0D:AC:13:35:F8', NULL, 'AC:12:03:87:9B:E6', @of31, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 111]
Último mantenimiento: 28/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 28/10/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON M2 (serie 3A5A_2702_3000_0FAB)
Usuario de Windows: Soporte
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.7.134
Sophos: ACTIVADO
AnyDesk ID: 1170502928', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13135'), (@eq, 2025, '2520');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of31, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 110: PCS ASIGNADAS fila 112
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WJ0', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-108', 'F8:0D:AC:13:39:13', NULL, 'AC:12:03:85:97:F6', @of31, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 112]
Último mantenimiento: 20/05/2026
Vida útil propuesta (meses): 6
Baja sugerida: 20/11/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON M2 (serie 3A5A_2702_3000_166D)
Usuario de Windows: Soporte
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.9.22
Sophos: ACTIVADO
AnyDesk ID: 1443288880', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13134');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of31, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: DALMER COSCCO
SET @pe86 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'DALMER COSCCO' OR (nombres = 'Dalmer' AND apellidos = 'Coscco') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Dalmer', 'Coscco', @of30 FROM DUAL WHERE @pe86 IS NULL;
SET @pe86 = COALESCE(@pe86, (SELECT id FROM personal WHERE nombres = 'Dalmer' AND apellidos = 'Coscco' ORDER BY id DESC LIMIT 1));

-- Equipo 111: PCS ASIGNADAS fila 113
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, 'PC2025-02', NULL, NULL, NULL, @of30, @pe86, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 113]
Último mantenimiento: 20/05/2026
Vida útil propuesta (meses): 24
Baja sugerida: 20/05/2028
Antigüedad: 1 AÑO
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0AF7)
Usuario de Windows: DALMER
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2536');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of30, @pe86, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: JOSE ARAUCO
SET @pe87 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'JOSE ARAUCO' OR (nombres = 'Jose' AND apellidos = 'Arauco') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Jose', 'Arauco', @of29 FROM DUAL WHERE @pe87 IS NULL;
SET @pe87 = COALESCE(@pe87, (SELECT id FROM personal WHERE nombres = 'Jose' AND apellidos = 'Arauco' ORDER BY id DESC LIMIT 1));

-- Equipo 112: PCS ASIGNADAS fila 114
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G8', '5CD0386WH4', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', NULL, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-95', NULL, NULL, NULL, @of29, @pe87, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 114]
Último mantenimiento: 02/03/2026
Vida útil propuesta (meses): 6
Baja sugerida: 02/09/2026
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 0000_0006_0000_0000_3A5A_2702_3000_0FB9)
Usuario de Windows: soporte
Núcleos/hilos CPU: 4/8
Modelo de disco: WDC WD10SPZX-60Z10T0
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13187'), (@eq, 2025, '2466');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of29, @pe87, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 113: PCS ASIGNADAS fila 115
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, NULL, 'SSD', NULL, NULL, NULL, NULL, NULL, NULL, @of29, @pe87, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: PCS ASIGNADAS fila 115]
Último mantenimiento: 24/04/2026
Vida útil propuesta (meses): 24
Baja sugerida: 24/04/2028
Antigüedad: 1 AÑO
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0EDF)
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2535');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of29, @pe87, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Personal: GUSTAVO MORI
SET @pe88 = (SELECT id FROM personal WHERE CONCAT(nombres, ' ', apellidos) = 'GUSTAVO MORI' OR (nombres = 'Gustavo' AND apellidos = 'Mori') LIMIT 1);
INSERT INTO personal (nombres, apellidos, oficina_id) SELECT 'Gustavo', 'Mori', @of30 FROM DUAL WHERE @pe88 IS NULL;
SET @pe88 = COALESCE(@pe88, (SELECT id FROM personal WHERE nombres = 'Gustavo' AND apellidos = 'Mori' ORDER BY id DESC LIMIT 1));

-- Equipo 114: PCS ASIGNADAS fila 116
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0384NPJ', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', NULL, 'NVME', 932, 'Microsoft Windows 10 Pro', 'PC2020-119', 'F8:0D:AC:12:97:8C', NULL, 'AC:12:03:85:74:C9', @of30, @pe88, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 116]
Último mantenimiento: 20/04/2026
Vida útil propuesta (meses): 6
Baja sugerida: 20/10/2026
Antigüedad: 5 AÑOS
Disco sólido: TeamGroup (serie 0000_0006_0000_0000_3A5A_2702_3000_0FE4)
Usuario de Windows: equintoo
Fecha BIOS: 23/08/2024
Núcleos/hilos CPU: 4/8
Modelo de disco: KINGSTON SNV3S1000G
IP Wi-Fi: 192.168.7.114
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14327'), (@eq, 2025, '1914');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of30, @pe88, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 115: PCS ASIGNADAS fila 117
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '2KQ3813', NULL, '57237', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', NULL, 'E4:54:E8:CB:96:65', '192.168.9.60', '40:5B:D8:7B:A5:C5', @of30, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 117]
Último mantenimiento: 12/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 12/07/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6A82D)
Usuario de Windows: rgalvezc
Fecha BIOS: 08/01/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: WDC WD10EZEX-75WN4A1
Sophos: ACTIVADO
AnyDesk ID: 351347909
Hostname PC2020-68 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14422'), (@eq, 2025, '1518');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of30, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 116: PCS ASIGNADAS fila 118
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CLZ74Y2', NULL, '55562', 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-27', 'EC:5C:68:B8:8B:F3', '192.168.9.47', NULL, @of30, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 118]
Último mantenimiento: 29/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 29/07/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6982B)
Usuario de Windows: programador1
Fecha BIOS: 19/10/2019
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13101'), (@eq, 2025, '2524');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of30, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aulas
SET @of32 = (SELECT id FROM oficinas WHERE nombre = 'Aulas' AND padre_id <=> NULL LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT NULL, 'Aulas', NULL, 'OFICINA' FROM DUAL WHERE @of32 IS NULL;
SET @of32 = COALESCE(@of32, (SELECT id FROM oficinas WHERE nombre = 'Aulas' AND padre_id <=> NULL LIMIT 1));

-- Oficina: Aula Perú
SET @of33 = (SELECT id FROM oficinas WHERE nombre = 'Aula Perú' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Perú', NULL, 'OFICINA' FROM DUAL WHERE @of33 IS NULL;
SET @of33 = COALESCE(@of33, (SELECT id FROM oficinas WHERE nombre = 'Aula Perú' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 117: PCS ASIGNADAS fila 119
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '15Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-90', 'E4:54:E8:CB:90:66', '192.168.18.10', '40:5B:D8:46:AC:33', @of33, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 119]
Último mantenimiento: 14/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 14/07/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0EE3)
Usuario de Windows: AULA PERU
Fecha BIOS: 01/10/2021
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12819'), (@eq, 2025, '2567');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of33, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Salón Marín
SET @of34 = (SELECT id FROM oficinas WHERE nombre = 'Salón Marín' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Salón Marín', NULL, 'OFICINA' FROM DUAL WHERE @of34 IS NULL;
SET @of34 = COALESCE(@of34, (SELECT id FROM oficinas WHERE nombre = 'Salón Marín' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 118: PCS ASIGNADAS fila 120
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 450 G7', '5CD0386WJ2', NULL, NULL, 'Intel(R) Core(TM) i7-10510U CPU @ 1.80GHz', 8, 'SSD', 466, 'Microsoft Windows 10 Pro', 'MARIN', 'F8:0D:AC:13:39:CF', '192.168.8.50', 'AC:12:03:85:A6:10', @of34, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 120]
Último mantenimiento: 29/03/2026
Vida útil propuesta (meses): 6
Baja sugerida: 29/09/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON M2 (serie 6479_A784_9AC0_ 04A)
Usuario de Windows: Salon Marin
Fecha BIOS: 23/08/2024
Núcleos/hilos CPU: 4/8
Modelo de disco: MSI M450 500GB
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2654');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of34, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aula Bolognesi
SET @of35 = (SELECT id FROM oficinas WHERE nombre = 'Aula Bolognesi' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Bolognesi', NULL, 'OFICINA' FROM DUAL WHERE @of35 IS NULL;
SET @of35 = COALESCE(@of35, (SELECT id FROM oficinas WHERE nombre = 'Aula Bolognesi' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 119: PCS ASIGNADAS fila 121
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '27Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 11 Pro', 'PC2020-93', 'E4:54:E8:CB:4B:49', '192.168.18.30', '40:5B:D8:46:05:5F', @of35, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 121]
Último mantenimiento: 27/02/2026
Vida útil propuesta (meses): 6
Baja sugerida: 27/08/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B76867B0F32)
Usuario de Windows: AULA BOLOGNESI
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13233');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of35, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aula Quiñones
SET @of36 = (SELECT id FROM oficinas WHERE nombre = 'Aula Quiñones' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Quiñones', NULL, 'OFICINA' FROM DUAL WHERE @of36 IS NULL;
SET @of36 = COALESCE(@of36, (SELECT id FROM oficinas WHERE nombre = 'Aula Quiñones' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 120: PCS ASIGNADAS fila 122
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '35Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-61', NULL, '192.168.18.40', NULL, @of36, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 122]
Último mantenimiento: 26/02/2026
Vida útil propuesta (meses): 6
Baja sugerida: 26/08/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE9E0)
Usuario de Windows: AULA QUIÑONES
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12639'), (@eq, 2025, '2584');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of36, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aula Grau
SET @of37 = (SELECT id FROM oficinas WHERE nombre = 'Aula Grau' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Grau', NULL, 'OFICINA' FROM DUAL WHERE @of37 IS NULL;
SET @of37 = COALESCE(@of37, (SELECT id FROM oficinas WHERE nombre = 'Aula Grau' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 121: PCS ASIGNADAS fila 123
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '52QHT13', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-88', 'E4:54:E8:D1:0F:09', '192.168.18.20', 'E8:6F:38:45:BB:9F', @of37, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 123]
Último mantenimiento: 26/02/2026
Vida útil propuesta (meses): 6
Baja sugerida: 26/08/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AEAFB)
Usuario de Windows: AULA GRAU
Fecha BIOS: 13/12/2023
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO
AnyDesk ID: 1708225239', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13325'), (@eq, 2025, '2577');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of37, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aula Valer
SET @of38 = (SELECT id FROM oficinas WHERE nombre = 'Aula Valer' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Valer', NULL, 'OFICINA' FROM DUAL WHERE @of38 IS NULL;
SET @of38 = COALESCE(@of38, (SELECT id FROM oficinas WHERE nombre = 'Aula Valer' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 122: PCS ASIGNADAS fila 124
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'D6Q3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-89', 'E4:54:E8:CB:DA:30', '192.168.18.50', '40:5B:D8:46:05:11', @of38, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 124]
Último mantenimiento: 14/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 14/07/2026
Antigüedad: 5 AÑOS
Disco sólido: KINGSTON A400 (serie 50026B77854AE3EF)
Usuario de Windows: AULA VALER
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37480G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13532'), (@eq, 2025, '2602');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of38, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Aula Cáceres
SET @of39 = (SELECT id FROM oficinas WHERE nombre = 'Aula Cáceres' AND padre_id <=> @of32 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of32, 'Aula Cáceres', NULL, 'OFICINA' FROM DUAL WHERE @of39 IS NULL;
SET @of39 = COALESCE(@of39, (SELECT id FROM oficinas WHERE nombre = 'Aula Cáceres' AND padre_id <=> @of32 LIMIT 1));

-- Equipo 123: PCS ASIGNADAS fila 125
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'FJQ3813', NULL, '55544', 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-92', 'E4:54:E8:CB:92:37', '192.168.18.60', '40:5B:D8:7B:61:3F', @of39, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 125]
Último mantenimiento: 14/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 14/07/2026
Antigüedad: 5 AÑOS
N° de informe: PRIMERO
PECOSA: PECOSA N° 016-2024
Disco sólido: KINGSTON A400 (serie 50026B7785C63AAA)
Usuario de Windows: AULA CACERES
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO
AnyDesk ID: 1795030066', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13437'), (@eq, 2025, '2595');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of39, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Almacén OTIC
SET @of40 = (SELECT id FROM oficinas WHERE nombre = 'Almacén OTIC' AND padre_id <=> @of26 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of26, 'Almacén OTIC', NULL, 'OFICINA' FROM DUAL WHERE @of40 IS NULL;
SET @of40 = COALESCE(@of40, (SELECT id FROM oficinas WHERE nombre = 'Almacén OTIC' AND padre_id <=> @of26 LIMIT 1));

-- Equipo 124: PCS ASIGNADAS fila 126
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JKS3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-9', 'E4:54:E8:98:FF:43', '192.168.8.66', 'C0:B5:D7:93:7D:C7', @of40, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 126]
Vida útil propuesta (meses): 6
Baja sugerida: 182
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D6ABF5)
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15935'), (@eq, 2025, '1174');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 125: PCS ASIGNADAS fila 127
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'LENOVO', 'LENOVOideapad 520', 'PF186A31', NULL, NULL, 'Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz', 8, 'HDD', 932, NULL, NULL, NULL, NULL, NULL, @of40, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 127]
Último mantenimiento: 04/06/2026
Vida útil propuesta (meses): 6
Baja sugerida: 04/12/2026
Antigüedad: 5 AÑOS
PECOSA: PECOSA N° 587-2025
Disco sólido: KINGSTON A400 (serie 50026B76872A0ED1)
Núcleos/hilos CPU: 4/8
Modelo de disco: ST1000LM035-1RK172
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14019'), (@eq, 2025, '2462');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 126: PCS ASIGNADAS fila 128
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'LENOVO', 'Lenovo 520-15IKB 81BF', 'PF0YTWAC', NULL, NULL, 'Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'FREDYBALDEON', NULL, NULL, '8C:16:45:4E:F3:6F', @of40, NULL, 'OPERATIVO', 'REGULAR', @vida, '[Importado de Excel: PCS ASIGNADAS fila 128]
Último mantenimiento: 28/01/2026
Vida útil propuesta (meses): 6
Baja sugerida: 28/07/2026
Antigüedad: 5 AÑOS
N° de informe: SEGUNDO
PECOSA: PECOSA N° 088-2025
Disco sólido: KINGSTON A400 (serie 50026B7785D698FD)
Usuario de Windows: PAOLA MUÑOZ
Fecha BIOS: 23/01/2018
Núcleos/hilos CPU: 4/8
Modelo de disco: ST1000LM035-1RK172
IP Wi-Fi: 192.168.7.122
Sophos: ACTIVADO', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14045');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 127: EQUIPOS DE BAJA fila 4
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CRFWNY2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 11 Pro', 'PC2020-41', 'C0:B5:D7:A4:61:0D', '192.168.0.156', NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 4]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: DIRECCIÓN ACADÉMICA
Último usuario: JOSE LUIS SERNAQUE DURAND
Usuario de Windows: soporte
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
MAC Wi-Fi igual a la MAC LAN: se omitió.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13895'), (@eq, 2025, '2622');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 128: EQUIPOS DE BAJA fila 5
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'CD1H933', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 5]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: BIBLIOTECA
Último usuario: (ACUÑA)
Usuario de Windows: SOPORTE
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13924'), (@eq, 2025, '2619');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 129: EQUIPOS DE BAJA fila 6
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '3LQ3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'HDD', 894, 'Microsoft Windows 10 Pro', 'PC2020-70', '40:5B:D8:7B:5B:D1', '192.168.7.226', NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 6]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: DPTO. DIPLOMADOS
Último usuario: JARA
Usuario de Windows: _
Núcleos/hilos CPU: 8/8
Modelo de disco: ST1000DM010-2EP102', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15862'), (@eq, 2025, '2399');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 130: EQUIPOS DE BAJA fila 7
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', 'F4Q3813', NULL, NULL, NULL, 8, 'HDD', 894, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 7]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: VIGILANCIA
Último usuario: LEYVA
Usuario de Windows: _
Modelo de disco: ST1000DM010', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '12869'), (@eq, 2025, '2623');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 131: EQUIPOS DE BAJA fila 8
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8331WPV', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2019-133', '10:E7:C6:B4:4B:66', '192.168.8.37', NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 8]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: GRADOS Y RESOLUCIONES
Último usuario: WILMER SANTOS VIDAL YACUPOMA
Usuario de Windows: wvidaly
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13911'), (@eq, 2025, '2621');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 132: EQUIPOS DE BAJA fila 9
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', 'MXL4472CK1', NULL, NULL, NULL, 8, 'HDD', 894, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 9]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: DPT. DE RRHH
Último usuario: QUISPE MENDOZA HENRY
Usuario de Windows: _
Modelo de disco: ST1000DM010', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13639'), (@eq, 2025, '833');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 133: EQUIPOS DE BAJA fila 10
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'HP', 'HP ProDesk 400 G5 SFF', 'MXL8351GL6', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2019-05', '10:E7:C6:B4:C3:FD', '192.168.8.48', NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 10]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: DPTO. AULAS VIRTUALES (maestrías)
Último usuario: GERARDO JOHEL RAMOS HUARANGA
Usuario de Windows: napazah
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15832'), (@eq, 2025, '1219');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 134: EQUIPOS DE BAJA fila 11
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM054Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PC2020-21', 'E4:54:E8:9B:20:D0', '192.168.9.32', 'EC:5C:68:B8:8B:C5', @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 11]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: DIRECCIÓN DE INVESTIGACIÓN
Último usuario: VANESSA YANIZ PALOMINO MONTEZA
Usuario de Windows: jalberto
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14450'), (@eq, 2025, '1524');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 135: EQUIPOS DE BAJA fila 12
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', 'GKQ3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-87', 'E4:54:E8:CB:B9:FD', '192.168.8.70', '40:5B:D8:7B:73:71', @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 12]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: BIBLIOTECA
Último usuario: GERARDO MANUEL ROJAS LEAL
Usuario de Windows: grojasl
Núcleos/hilos CPU: 8/8
Modelo de disco: WDC WD10EZEX-75WN4A1', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15774'), (@eq, 2025, '1942');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 136: EQUIPOS DE BAJA fila 13
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3471', '8KQ3813', NULL, NULL, 'Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz', 8, 'SSD', 932, 'Microsoft Windows 10 Pro', NULL, 'E4:54:E8:CB:BD:78', NULL, '40:5B:D8:7B:A4:A9', @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 13]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: INSTITUTO MARÍN
Último usuario: ORLANDO CUADRA RODRIGUEZ
Usuario de Windows: ocuadrar
Núcleos/hilos CPU: 8/8
Modelo de disco: KINGSTON SA400S37960G
IP Wi-Fi: 192.168.7.250
Hostname PC2020-84 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15649'), (@eq, 2025, '1973');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 137: EQUIPOS DE BAJA fila 14
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'HP', 'HP ProBook 650 G4', '5CG94666VQ', NULL, NULL, NULL, 8, 'SSD', 932, 'Microsoft Windows 10 Pro', 'PC2020-52', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 14]
Para baja: DAÑOS EN LA PANTALLA
Informe: TIENE INFORME
Oficina de origen: GRADOS Y RESOLUCIONES
Último usuario: CASTILLO ALATRISTA
Usuario de Windows: HP
Núcleos/hilos CPU: 6/8
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13926');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 138: EQUIPOS DE BAJA fila 15
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CRDWNY2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 447, 'Microsoft Windows 10 Pro', 'PC2020-37', 'E4:54:E8:9B:0A:D1', '192.168.9.230', NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 15]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: FINANZAS
Último usuario: ELIANA GABRIELA DELGADO PEROZO
Usuario de Windows: transmision
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37480G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13010'), (@eq, 2025, '1024');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 139: EQUIPOS DE BAJA fila 16
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CG94666VR', NULL, NULL, NULL, 8, 'HDD', 447, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 16]
Para baja: DAÑOS EN LOS TECLADOS
Informe: TIENE INFORME
Oficina de origen: OPP
Último usuario: JOANA ORUE
Disco sólido: 50026B7686EAEC6C KINGSTON M2
Usuario de Windows: _
Modelo de disco: ST1000DM010', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13185'), (@eq, 2025, '2877');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 140: EQUIPOS DE BAJA fila 17
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, 8, 'HDD', 447, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 17]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: ALMACÉN
Último usuario: ANTIGUA
Usuario de Windows: _
Modelo de disco: ST1000DM010', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '2240'), (@eq, 2025, '14250');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 141: EQUIPOS DE BAJA fila 18
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', NULL, NULL, NULL, NULL, 8, 'HDD', 447, 'Microsoft Windows 10 Pro', NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 18]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: ALMACÉN
Último usuario: ANTIGUA
Usuario de Windows: _
Modelo de disco: ST1000DM010', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '2243'), (@eq, 2025, '13222');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 142: EQUIPOS DE BAJA fila 19
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', 'CM484Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'SSD', 894, 'Microsoft Windows 10 Pro', 'PPONCER', 'E4:54:E8:9B:1B:9D', '192.168.7.125', 'EC:5C:68:B6:D4:35', @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 19]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: URRI
Último usuario: PEDRO PABLO PONCE RODRIGUEZ
Usuario de Windows: pponcer
Núcleos/hilos CPU: 6/12
Modelo de disco: KINGSTON SA400S37960G', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15595'), (@eq, 2025, '2191');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 143: EQUIPOS DE BAJA fila 20
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'DELL', 'Vostro 3470', '8JTS3Y2', NULL, NULL, 'Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz', 8, 'HDD', 932, 'Microsoft Windows 10 Pro', 'PC2020-42', 'C0:B5:D7:93:7F:3B', '192.168.9.144', 'AC:12:03:86:40:5C', @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 20]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: SIN USUARIO
Último usuario: SIN USUARIO
Núcleos/hilos CPU: 6/12
Modelo de disco: ST1000DM010-2EP102
IP Wi-Fi: 192.168.7.90', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15948'), (@eq, 2025, '1169');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 144: EQUIPOS DE BAJA fila 21
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', 'GMORIT', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 21]
Para baja: DAÑOS EN LA PLACA
Informe: TIENE INFORME
Oficina de origen: Gustavo Adolfo Mori Temoche
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13116'), (@eq, 2025, '2319');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 145: EQUIPOS DE BAJA fila 22
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', 'MXL8351GMX', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2019-129', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 22]
Para baja: CON PROBLEMAS DE TARJETA
Informe: TIENE INFORME
Oficina de origen: DIRECCION GENERAL
Último usuario: PAOLA CARMEN
Disco sólido: 50026B7785D6ABF5
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 146: EQUIPOS DE BAJA fila 23
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', '8JNX3Y2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2020-39', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 23]
Para baja: PROBLEMAS DE CONDENSADORES
Informe: NO TIENE
Oficina de origen: AULAS VIRTUALES
Último usuario: MAURO
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15942'), (@eq, 2025, '1258');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 147: EQUIPOS DE BAJA fila 24
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CD0386WHD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2020-97', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 24]
Para baja: DAÑOS EN LA PANTALLA
Informe: NO TIENE
Oficina de origen: SECRETARIA GENERAL
Último usuario: GIOVANNA CARLES TALLEDO
Disco sólido: 50026B7686E97F0D
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14044');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 148: EQUIPOS DE BAJA fila 25
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CD0386WBX', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2020-116', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 25]
Para baja: DAÑOS EN LA PANTALLA
Informe: TIENE INFORME
Oficina de origen: FINANZAS
Último usuario: JORGE LUIS OLAYA COPAJA
Disco sólido: 3A5A_2702_3000_1672
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13016'), (@eq, 2025, '1013');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 149: EQUIPOS DE BAJA fila 26
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('PC', 'SIN MARCA', 'SIN MODELO', 'CRCSNY2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2020-29', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 26]
Para baja: DAÑOS EN LA PLACA
Informe: NO TIENE
Oficina de origen: BIBLIOTECA
Último usuario: JESSICA JULISSA TENORIO TEJEDA
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15765'), (@eq, 2025, '1582');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 150: EQUIPOS DE BAJA fila 27
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('LAPTOP', 'SIN MARCA', 'SIN MODELO', '5CD0384NT5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PC2020-117', NULL, NULL, NULL, @of40, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: EQUIPOS DE BAJA fila 27]
Para baja: DAÑOS EN LA PANTALLA
Informe: NO TIENE
Oficina de origen: OPP
Último usuario: ÑAÑA
Disco sólido: REGULAR
Fila con columnas desalineadas en el Excel: complete modelo y hardware manualmente.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14324');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of40, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 151: IMPRESORAS fila 2
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'EPSON', 'L5590', 'XBBX043160', '740836500001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of15, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 2]
Uso: EN USO
Mantenimiento 2025: 27/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15930');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 152: IMPRESORAS fila 3
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931171', '742223580021', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of2, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 3]
Uso: EN USO
Mantenimiento 2025: 14/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of2, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 153: IMPRESORAS fila 4
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8090', '3669212282', '72223580022', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of3, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: IMPRESORAS fila 4]
Uso: PARA BAJA
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13094');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of3, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 154: IMPRESORAS fila 5
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141926453', '742223580016', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of4, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 5]
Uso: EN USO
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15839');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of4, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 155: IMPRESORAS fila 6
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8065', '3669213998', '742223580019', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of1, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: IMPRESORAS fila 6]
Uso: PARA BAJA
Mantenimiento 2025: 14/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15309');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of1, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: División de Matrículas
SET @of41 = (SELECT id FROM oficinas WHERE nombre = 'División de Matrículas' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'División de Matrículas', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of41 IS NULL;
SET @of41 = COALESCE(@of41, (SELECT id FROM oficinas WHERE nombre = 'División de Matrículas' AND padre_id <=> @of1 LIMIT 1));

-- Equipo 156: IMPRESORAS fila 7
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8065', '3669212703', '742223580020', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of41, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 7]
Uso: EN USO
Mantenimiento 2025: 25/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15336');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of41, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. Simulación
SET @of42 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. Simulación' AND padre_id <=> @of1 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of1, 'Dpto. Simulación', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of42 IS NULL;
SET @of42 = COALESCE(@of42, (SELECT id FROM oficinas WHERE nombre = 'Dpto. Simulación' AND padre_id <=> @of1 LIMIT 1));

-- Equipo 157: IMPRESORAS fila 8
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'EPSON', 'L5590', 'XBBX042891', '740836500003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of42, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 8]
Uso: EN USO
Mantenimiento 2025: 27/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of42, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 158: IMPRESORAS fila 9
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141926704', '72223580001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of8, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 9]
Uso: EN USO
Mantenimiento 2025: 21/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of8, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 159: IMPRESORAS fila 10
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'HP', 'LI P1102W', 'BRBSG4HGGT', '740845500001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of9, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 10]
Uso: EN USO
Mantenimiento 2025: 01/12/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 160: IMPRESORAS fila 11
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931074', '72223580004', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of9, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 11]
Uso: EN USO
Mantenimiento 2025: 21/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of9, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 161: IMPRESORAS fila 12
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8171', '3141931198', '742223580023', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of10, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 12]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of10, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Dpto. de Investigación
SET @of43 = (SELECT id FROM oficinas WHERE nombre = 'Dpto. de Investigación' AND padre_id <=> @of14 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of14, 'Dpto. de Investigación', NULL, 'DEPARTAMENTO' FROM DUAL WHERE @of43 IS NULL;
SET @of43 = COALESCE(@of43, (SELECT id FROM oficinas WHERE nombre = 'Dpto. de Investigación' AND padre_id <=> @of14 LIMIT 1));

-- Equipo 162: IMPRESORAS fila 13
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8065', '3669209141', '742223580014', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of43, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 13]
Uso: EN USO
Mantenimiento 2025: 14/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '14434');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of43, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 163: IMPRESORAS fila 14
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141926445', '742223580018', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of14, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 14]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of14, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Biblioteca
SET @of44 = (SELECT id FROM oficinas WHERE nombre = 'Biblioteca' AND padre_id <=> @of14 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of14, 'Biblioteca', NULL, 'OFICINA' FROM DUAL WHERE @of44 IS NULL;
SET @of44 = COALESCE(@of44, (SELECT id FROM oficinas WHERE nombre = 'Biblioteca' AND padre_id <=> @of14 LIMIT 1));

-- Equipo 164: IMPRESORAS fila 15
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'EPSON', 'L3210', 'XAGB186951', '740836500002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of44, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 15]
Uso: EN USO
Mantenimiento 2025: 27/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15801');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of44, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 165: IMPRESORAS fila 16
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8171', '3141931155', '742223580013', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of15, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 16]
Uso: SIN TONER
Mantenimiento 2025: 25/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13673');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of15, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 166: IMPRESORAS fila 17
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931139', '742223580006', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of12, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 17]
Uso: EN USO
Mantenimiento 2025: 26/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15098');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of12, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 167: IMPRESORAS fila 18
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141926780', '742223580010', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of17, NULL, 'INOPERATIVO', 'MALO', @vida, '[Importado de Excel: IMPRESORAS fila 18]
Uso: SIN SUMINISTROS
Mantenimiento 2025: 14/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '16307');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of17, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Oficina: Grados y Títulos
SET @of45 = (SELECT id FROM oficinas WHERE nombre = 'Grados y Títulos' AND padre_id <=> @of15 LIMIT 1);
INSERT INTO oficinas (padre_id, nombre, siglas, tipo) SELECT @of15, 'Grados y Títulos', NULL, 'OFICINA' FROM DUAL WHERE @of45 IS NULL;
SET @of45 = COALESCE(@of45, (SELECT id FROM oficinas WHERE nombre = 'Grados y Títulos' AND padre_id <=> @of15 LIMIT 1));

-- Equipo 168: IMPRESORAS fila 19
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'VERSALTALINK C8000', '3770615932', '742223580007', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of45, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 19]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of45, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 169: IMPRESORAS fila 20
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141926674', '742223580017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of18, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 20]
Uso: EN USO
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15561');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 170: IMPRESORAS fila 21
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'RICOH', 'P C600', '5321XA21453', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of18, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 21]
Uso: EN USO
Mantenimiento 2025: 09/12/2025
Código patrimonial 742223580017 repetido en el Excel: no se guardó.', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15552');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of18, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 171: IMPRESORAS fila 22
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8090', '3669225759', '72223580015', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of19, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 22]
Uso: EN USO
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15608');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of19, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 172: IMPRESORAS fila 23
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931104', '742223580009', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of20, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 23]
Uso: EN USO
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2084');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of20, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 173: IMPRESORAS fila 24
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8171', '3141926470', '742223580005', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of21, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 24]
Uso: EN USO
Mantenimiento 2025: 20/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13839');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of21, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 174: IMPRESORAS fila 25
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141927158', '7422235800012', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of22, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 25]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '15399');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of22, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 175: IMPRESORAS fila 26
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'RICOH', 'P C600', '5321XA21457', '740841000002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of22, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 26]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of22, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 176: IMPRESORAS fila 27
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'HP', 'SMART TANK 500', 'CN9CT2436N', '742223580003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of23, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 27]
Uso: EN USO
Mantenimiento 2025: 27/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 177: IMPRESORAS fila 28
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'VERSALINK B615', '3395158413', '742223580011', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of23, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 28]
Uso: EN USO
Mantenimiento 2025: 26/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of23, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 178: IMPRESORAS fila 29
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'EPSON', 'L5590', 'XBBX043190', '740836500004', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of24, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 29]
Uso: EN USO
Mantenimiento 2025: 27/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of24, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 179: IMPRESORAS fila 30
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931163', '742223580002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of25, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 30]
Uso: EN USO
Mantenimiento 2025: 24/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2024, '13731');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of25, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 180: IMPRESORAS fila 31
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'XEROX', 'ALTALINK B8170', '3141931210', '72223580008', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of26, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 31]
Uso: EN USO
Mantenimiento 2025: 21/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO equipo_codigos (equipo_id, anio, codigo) VALUES (@eq, 2025, '2328');
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of26, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);

-- Equipo 181: IMPRESORAS fila 32
INSERT INTO equipos (tipo, marca, modelo, nro_serie, codigo_patrimonial, codigo_interno, procesador, ram_gb, disco_tipo, disco_capacidad_gb, sistema_operativo, hostname, mac_lan, ip_lan, mac_wifi, oficina_id, personal_id, estado_operativo, condicion_fisica, vida_util_meses, observaciones, created_by, updated_by)
  VALUES ('IMPRESORA', 'HP', 'LI P1102W', 'BRBSG4GH9G', '740836500005', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @of26, NULL, 'OPERATIVO', 'BUENO', @vida, '[Importado de Excel: IMPRESORAS fila 32]
Uso: EN USO
Mantenimiento 2025: 01/11/2025', @usr, @usr);
SET @eq = LAST_INSERT_ID();
INSERT INTO historial_asignaciones (equipo_id, oficina_id, personal_id, motivo, observacion, usuario_id) VALUES (@eq, @of26, NULL, 'ALTA', 'Alta del equipo en el inventario', @usr);


COMMIT;

SELECT COUNT(*) AS equipos_importados FROM equipos WHERE observaciones LIKE '[Importado de Excel%';
