-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: sigpat_otic
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL en intentos de login con usuario inexistente',
  `usuario_login` varchar(50) DEFAULT NULL COMMENT 'Nombre de usuario usado (snapshot)',
  `accion` enum('CREAR','EDITAR','ELIMINAR','LOGIN','LOGIN_FALLIDO','LOGOUT','ASIGNAR','ASIGNAR_SLOT','LIBERAR_SLOT','CERRAR','EMITIR','BAJA') NOT NULL,
  `tabla` varchar(64) DEFAULT NULL,
  `registro_id` varchar(64) DEFAULT NULL COMMENT 'PK afectada (texto para admitir claves no numéricas)',
  `datos_antes` longtext DEFAULT NULL,
  `datos_despues` longtext DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_auditoria_usuario_fecha` (`usuario_id`,`created_at`),
  KEY `idx_auditoria_accion_fecha` (`accion`,`created_at`),
  KEY `idx_auditoria_tabla_registro` (`tabla`,`registro_id`),
  KEY `idx_auditoria_created_at` (`created_at`),
  CONSTRAINT `fk_auditoria_usuario_id` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_auditoria_datos_antes` CHECK (`datos_antes` is null or json_valid(`datos_antes`)),
  CONSTRAINT `chk_auditoria_datos_despues` CHECK (`datos_despues` is null or json_valid(`datos_despues`))
) ENGINE=InnoDB AUTO_INCREMENT=1176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de auditoría de acciones de los usuarios del sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES (1,1,'admin','EDITAR','usuarios_sistema','1',NULL,'{\"usuario\":\"admin\",\"cambio\":\"Cambio de contraseña propia\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.138.0 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36','2026-09-22 15:15:51'),(2,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 15:16:20'),(25,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 20:22:44'),(26,1,'admin','LOGIN_FALLIDO','usuarios_sistema','1',NULL,'{\"motivo\":\"Contraseña incorrecta\",\"intento\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.138.0 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36','2026-09-22 20:23:44'),(27,1,'admin','LOGIN_FALLIDO','usuarios_sistema','1',NULL,'{\"motivo\":\"Contraseña incorrecta\",\"intento\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.138.0 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36','2026-09-22 20:24:06'),(28,1,'admin','LOGOUT','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 20:24:19'),(29,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 20:25:16'),(30,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.138.0 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36','2026-09-22 20:29:49'),(862,1,'admin','LOGOUT','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 21:53:30'),(863,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','2026-09-22 21:53:36'),(864,1,'admin','LOGIN_FALLIDO','usuarios_sistema','1',NULL,'{\"motivo\":\"Contraseña incorrecta\",\"intento\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-09-23 10:23:23'),(865,1,'admin','LOGIN','usuarios_sistema','1',NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-09-23 10:23:32');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo_software`
--

DROP TABLE IF EXISTS `catalogo_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo_software` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `orden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_catalogo_software_nombre` (`nombre`),
  KEY `idx_catalogo_software_activo_orden` (`activo`,`orden`),
  CONSTRAINT `chk_catalogo_software_activo` CHECK (`activo` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Catálogo administrable de software instalable en mantenimientos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo_software`
--

LOCK TABLES `catalogo_software` WRITE;
/*!40000 ALTER TABLE `catalogo_software` DISABLE KEYS */;
INSERT INTO `catalogo_software` VALUES (1,'Sophos Antivirus',NULL,10,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(2,'Microsoft Office',NULL,20,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(3,'Google Drive',NULL,30,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(4,'AnyDesk',NULL,40,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(5,'Zoom',NULL,50,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(6,'Adobe Reader',NULL,60,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(7,'Epson iProjection',NULL,70,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(8,'Xerox SmartStart',NULL,80,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(9,'SIGA',NULL,90,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(10,'SIAF',NULL,100,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(11,'ReFirma',NULL,110,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(12,'CheckPoint VPN',NULL,120,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(13,'Java',NULL,130,1,'2026-09-22 15:12:04','2026-09-22 15:12:04');
/*!40000 ALTER TABLE `catalogo_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checklist_items`
--

DROP TABLE IF EXISTS `checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checklist_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(40) DEFAULT NULL COMMENT 'Identificador estable para ítems con lógica asociada (p. ej. FORMATEO_SO)',
  `categoria` enum('FISICO','LOGICO','RED') NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  `aplica_a` set('PC','LAPTOP','IMPRESORA') NOT NULL DEFAULT 'PC,LAPTOP,IMPRESORA',
  `orden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_checklist_items_categoria_descripcion` (`categoria`,`descripcion`),
  UNIQUE KEY `uq_checklist_items_codigo` (`codigo`),
  KEY `idx_checklist_items_categoria_orden` (`categoria`,`activo`,`orden`),
  CONSTRAINT `chk_checklist_items_activo` CHECK (`activo` in (0,1)),
  CONSTRAINT `chk_checklist_items_aplica_a` CHECK (`aplica_a` <> '')
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Actividades de mantenimiento (FISICO, LOGICO, RED) filtradas por tipo de equipo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checklist_items`
--

LOCK TABLES `checklist_items` WRITE;
/*!40000 ALTER TABLE `checklist_items` DISABLE KEYS */;
INSERT INTO `checklist_items` VALUES (1,NULL,'FISICO','Remoción de polvo con aire comprimido','PC,LAPTOP,IMPRESORA',10,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(2,NULL,'FISICO','Limpieza con brocha y alcohol isopropílico','PC,LAPTOP,IMPRESORA',20,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(3,'PASTA_TERMICA','FISICO','Cambio de pasta térmica','PC,LAPTOP',30,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(4,NULL,'FISICO','Aplicación de limpiacontactos en slots y conectores','PC,LAPTOP,IMPRESORA',40,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(5,NULL,'FISICO','Revisión y ajuste de conexiones internas','PC,LAPTOP,IMPRESORA',50,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(6,'FORMATEO_SO','LOGICO','Formateo y reinstalación de SO','PC,LAPTOP',10,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(7,NULL,'LOGICO','Respaldo de información','PC,LAPTOP',20,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(8,NULL,'LOGICO','Limpieza de temporales y caché','PC,LAPTOP',30,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(9,NULL,'LOGICO','Análisis y eliminación de virus','PC,LAPTOP',40,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(10,NULL,'LOGICO','Configuración y optimización del inicio','PC,LAPTOP',50,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(11,NULL,'LOGICO','Instalación/actualización de drivers','PC,LAPTOP',60,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(12,'DOMINIO','RED','Incorporación al dominio CAEN-EPG','PC,LAPTOP',10,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(13,'HOSTNAME','RED','Asignación de hostname según inventario','PC,LAPTOP,IMPRESORA',20,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(14,NULL,'RED','Configuración de impresora de red','PC,LAPTOP,IMPRESORA',30,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(15,NULL,'RED','Configuración Wi-Fi','PC,LAPTOP,IMPRESORA',40,1,'2026-09-22 15:12:04','2026-09-22 15:12:04');
/*!40000 ALTER TABLE `checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `correlativos`
--

DROP TABLE IF EXISTS `correlativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `correlativos` (
  `tipo` enum('MANTENIMIENTO','INFORME') NOT NULL,
  `anio` smallint(5) unsigned NOT NULL,
  `ultimo` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`tipo`,`anio`),
  CONSTRAINT `chk_correlativos_anio` CHECK (`anio` between 2000 and 2100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Último número emitido por tipo de documento y año (se bloquea con FOR UPDATE)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `correlativos`
--

LOCK TABLES `correlativos` WRITE;
/*!40000 ALTER TABLE `correlativos` DISABLE KEYS */;
INSERT INTO `correlativos` VALUES ('MANTENIMIENTO',2026,0,'2026-09-22 15:12:04','2026-09-23 04:19:45'),('INFORME',2026,0,'2026-09-22 15:12:04','2026-09-23 04:19:45');
/*!40000 ALTER TABLE `correlativos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_codigos`
--

DROP TABLE IF EXISTS `equipo_codigos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_codigos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `equipo_id` int(10) unsigned NOT NULL,
  `anio` smallint(5) unsigned NOT NULL,
  `codigo` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipo_codigos_equipo_anio` (`equipo_id`,`anio`),
  UNIQUE KEY `uq_equipo_codigos_anio_codigo` (`anio`,`codigo`),
  KEY `idx_equipo_codigos_codigo` (`codigo`),
  CONSTRAINT `fk_equipo_codigos_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_equipo_codigos_anio` CHECK (`anio` between 1990 and 2100)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Código de inventario asignado a cada equipo por año';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_codigos`
--

LOCK TABLES `equipo_codigos` WRITE;
/*!40000 ALTER TABLE `equipo_codigos` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipo_codigos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_puntos_red`
--

DROP TABLE IF EXISTS `equipo_puntos_red`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_puntos_red` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `equipo_id` int(10) unsigned NOT NULL,
  `codigo_punto` varchar(30) NOT NULL COMMENT 'Rotulado del punto de red (p. ej. P2-D-015)',
  `switch_puerto` varchar(60) DEFAULT NULL,
  `vlan` varchar(20) DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipo_puntos_red_equipo_punto` (`equipo_id`,`codigo_punto`),
  KEY `idx_equipo_puntos_red_codigo_punto` (`codigo_punto`),
  CONSTRAINT `fk_equipo_puntos_red_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Puntos de red a los que se conecta cada equipo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_puntos_red`
--

LOCK TABLES `equipo_puntos_red` WRITE;
/*!40000 ALTER TABLE `equipo_puntos_red` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipo_puntos_red` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('PC','LAPTOP','IMPRESORA') NOT NULL,
  `marca` varchar(60) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `nro_serie` varchar(80) DEFAULT NULL,
  `codigo_patrimonial` varchar(30) DEFAULT NULL,
  `codigo_interno` varchar(30) DEFAULT NULL,
  `procesador` varchar(120) DEFAULT NULL,
  `ram_gb` smallint(5) unsigned DEFAULT NULL,
  `disco_tipo` enum('HDD','SSD','NVME') DEFAULT NULL,
  `disco_capacidad_gb` int(10) unsigned DEFAULT NULL,
  `sistema_operativo` varchar(80) DEFAULT NULL,
  `hostname` varchar(63) DEFAULT NULL,
  `mac_lan` char(17) DEFAULT NULL,
  `ip_lan` varchar(45) DEFAULT NULL,
  `mac_wifi` char(17) DEFAULT NULL,
  `oficina_id` int(10) unsigned NOT NULL COMMENT 'Ubicación física (obligatoria)',
  `personal_id` int(10) unsigned DEFAULT NULL COMMENT 'Responsable; NULL = sin responsable (p. ej. impresora compartida)',
  `estado_operativo` enum('OPERATIVO','EN_MANTENIMIENTO','INOPERATIVO','DE_BAJA') NOT NULL DEFAULT 'OPERATIVO',
  `condicion_fisica` enum('BUENO','REGULAR','MALO') NOT NULL DEFAULT 'BUENO',
  `recomendado_baja` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = un informe EMITIDO recomienda la baja',
  `fecha_baja` date DEFAULT NULL,
  `fecha_adquisicion` date DEFAULT NULL,
  `vida_util_meses` smallint(5) unsigned NOT NULL DEFAULT 48,
  `periodicidad_mant_meses` tinyint(3) unsigned DEFAULT NULL COMMENT 'NULL = usar parametros.periodicidad_mant_meses',
  `valor_adquisicion` decimal(12,2) DEFAULT NULL,
  `orden_compra` varchar(50) DEFAULT NULL,
  `proveedor` varchar(150) DEFAULT NULL,
  `garantia_hasta` date DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipos_nro_serie` (`nro_serie`),
  UNIQUE KEY `uq_equipos_codigo_patrimonial` (`codigo_patrimonial`),
  UNIQUE KEY `uq_equipos_codigo_interno` (`codigo_interno`),
  UNIQUE KEY `uq_equipos_hostname` (`hostname`),
  UNIQUE KEY `uq_equipos_mac_lan` (`mac_lan`),
  UNIQUE KEY `uq_equipos_ip_lan` (`ip_lan`),
  UNIQUE KEY `uq_equipos_mac_wifi` (`mac_wifi`),
  KEY `idx_equipos_oficina_id` (`oficina_id`),
  KEY `idx_equipos_personal_id` (`personal_id`),
  KEY `idx_equipos_tipo_estado` (`tipo`,`estado_operativo`),
  KEY `idx_equipos_estado_operativo` (`estado_operativo`),
  KEY `idx_equipos_condicion_fisica` (`condicion_fisica`),
  KEY `idx_equipos_recomendado_baja` (`recomendado_baja`),
  KEY `idx_equipos_marca_modelo` (`marca`,`modelo`),
  KEY `idx_equipos_fecha_adquisicion` (`fecha_adquisicion`),
  KEY `idx_equipos_created_by` (`created_by`),
  KEY `idx_equipos_updated_by` (`updated_by`),
  CONSTRAINT `fk_equipos_created_by` FOREIGN KEY (`created_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_equipos_oficina_id` FOREIGN KEY (`oficina_id`) REFERENCES `oficinas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_equipos_personal_id` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_equipos_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_equipos_hardware_impresora` CHECK (`tipo` <> 'IMPRESORA' or `procesador` is null and `ram_gb` is null and `disco_tipo` is null and `disco_capacidad_gb` is null),
  CONSTRAINT `chk_equipos_mac_lan` CHECK (`mac_lan` is null or `mac_lan` regexp '^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$'),
  CONSTRAINT `chk_equipos_mac_wifi` CHECK (`mac_wifi` is null or `mac_wifi` regexp '^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$'),
  CONSTRAINT `chk_equipos_recomendado_baja` CHECK (`recomendado_baja` in (0,1)),
  CONSTRAINT `chk_equipos_vida_util` CHECK (`vida_util_meses` between 1 and 600),
  CONSTRAINT `chk_equipos_periodicidad` CHECK (`periodicidad_mant_meses` is null or `periodicidad_mant_meses` between 1 and 60),
  CONSTRAINT `chk_equipos_valor` CHECK (`valor_adquisicion` is null or `valor_adquisicion` >= 0),
  CONSTRAINT `chk_equipos_fecha_baja` CHECK (`fecha_baja` is null or `estado_operativo` = 'DE_BAJA')
) ENGINE=InnoDB AUTO_INCREMENT=657 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Inventario patrimonial de PC, laptops e impresoras';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

LOCK TABLES `equipos` WRITE;
/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_asignaciones`
--

DROP TABLE IF EXISTS `historial_asignaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historial_asignaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `equipo_id` int(10) unsigned NOT NULL,
  `oficina_id` int(10) unsigned NOT NULL,
  `personal_id` int(10) unsigned DEFAULT NULL,
  `fecha_inicio` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_fin` datetime DEFAULT NULL,
  `motivo` enum('ALTA','ASIGNACION','DESVINCULACION','TRASLADO','ROTACION','BAJA') NOT NULL DEFAULT 'ASIGNACION',
  `observacion` varchar(255) DEFAULT NULL,
  `usuario_id` int(10) unsigned DEFAULT NULL COMMENT 'Usuario del sistema que registró el movimiento',
  `equipo_vigente` int(10) unsigned GENERATED ALWAYS AS (if(`fecha_fin` is null,`equipo_id`,NULL)) STORED COMMENT 'Generada: garantiza un solo registro vigente por equipo',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_historial_asignaciones_equipo_vigente` (`equipo_vigente`),
  KEY `idx_historial_asignaciones_equipo_fecha` (`equipo_id`,`fecha_inicio`),
  KEY `idx_historial_asignaciones_oficina_id` (`oficina_id`),
  KEY `idx_historial_asignaciones_personal_id` (`personal_id`),
  KEY `idx_historial_asignaciones_usuario_id` (`usuario_id`),
  CONSTRAINT `fk_historial_asignaciones_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`),
  CONSTRAINT `fk_historial_asignaciones_oficina_id` FOREIGN KEY (`oficina_id`) REFERENCES `oficinas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_historial_asignaciones_personal_id` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_historial_asignaciones_usuario_id` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_historial_asignaciones_fechas` CHECK (`fecha_fin` is null or `fecha_fin` >= `fecha_inicio`)
) ENGINE=InnoDB AUTO_INCREMENT=630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historial de ubicación y responsable de cada equipo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_asignaciones`
--

LOCK TABLES `historial_asignaciones` WRITE;
/*!40000 ALTER TABLE `historial_asignaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `historial_asignaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `informe_equipos`
--

DROP TABLE IF EXISTS `informe_equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informe_equipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `informe_id` int(10) unsigned NOT NULL,
  `equipo_id` int(10) unsigned NOT NULL,
  `caracteristicas` text DEFAULT NULL,
  `estado_funcional` text DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `orden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_informe_equipos_informe_equipo` (`informe_id`,`equipo_id`),
  KEY `idx_informe_equipos_equipo_id` (`equipo_id`),
  CONSTRAINT `fk_informe_equipos_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_informe_equipos_informe_id` FOREIGN KEY (`informe_id`) REFERENCES `informes_tecnicos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Equipos evaluados en cada informe técnico';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `informe_equipos`
--

LOCK TABLES `informe_equipos` WRITE;
/*!40000 ALTER TABLE `informe_equipos` DISABLE KEYS */;
/*!40000 ALTER TABLE `informe_equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `informe_evidencias`
--

DROP TABLE IF EXISTS `informe_evidencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informe_evidencias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `informe_id` int(10) unsigned NOT NULL,
  `equipo_id` int(10) unsigned DEFAULT NULL COMMENT 'Equipo al que corresponde la foto (opcional)',
  `archivo` varchar(100) NOT NULL COMMENT 'Nombre aleatorio dentro de storage/evidencias',
  `nombre_original` varchar(255) NOT NULL,
  `mime` varchar(20) NOT NULL,
  `tamanio_bytes` int(10) unsigned NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `orden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subido_por` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_informe_evidencias_archivo` (`archivo`),
  KEY `idx_informe_evidencias_informe_orden` (`informe_id`,`orden`),
  KEY `idx_informe_evidencias_equipo_id` (`equipo_id`),
  KEY `idx_informe_evidencias_subido_por` (`subido_por`),
  CONSTRAINT `fk_informe_evidencias_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_informe_evidencias_informe_id` FOREIGN KEY (`informe_id`) REFERENCES `informes_tecnicos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_informe_evidencias_subido_por` FOREIGN KEY (`subido_por`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_informe_evidencias_mime` CHECK (`mime` in ('image/jpeg','image/png')),
  CONSTRAINT `chk_informe_evidencias_tamanio` CHECK (`tamanio_bytes` between 1 and 5242880)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Evidencias fotográficas (JPG/PNG, máx. 5 MB) de los informes técnicos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `informe_evidencias`
--

LOCK TABLES `informe_evidencias` WRITE;
/*!40000 ALTER TABLE `informe_evidencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `informe_evidencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `informes_tecnicos`
--

DROP TABLE IF EXISTS `informes_tecnicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informes_tecnicos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(30) DEFAULT NULL COMMENT 'N° 001-2026/OTIC; se asigna al emitir',
  `anio` smallint(5) unsigned DEFAULT NULL,
  `correlativo` int(10) unsigned DEFAULT NULL,
  `para_nombre` varchar(150) NOT NULL,
  `para_cargo` varchar(150) NOT NULL,
  `de_usuario_id` int(10) unsigned NOT NULL,
  `de_nombre` varchar(150) NOT NULL COMMENT 'Snapshot del nombre del técnico',
  `de_cargo` varchar(150) DEFAULT NULL COMMENT 'Snapshot del cargo del técnico',
  `asunto` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `antecedentes` text DEFAULT NULL,
  `accion_requerida` enum('REPARACION','INOPERATIVIDAD','BAJA_DEFINITIVA','REEMPLAZO') NOT NULL,
  `conclusiones` text DEFAULT NULL,
  `recomendaciones` text DEFAULT NULL,
  `estado` enum('BORRADOR','EMITIDO') NOT NULL DEFAULT 'BORRADOR',
  `emitido_por` int(10) unsigned DEFAULT NULL,
  `emitido_at` datetime DEFAULT NULL,
  `pdf_ruta` varchar(255) DEFAULT NULL,
  `docx_ruta` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_informes_tecnicos_numero` (`numero`),
  UNIQUE KEY `uq_informes_tecnicos_anio_correlativo` (`anio`,`correlativo`),
  KEY `idx_informes_tecnicos_estado_fecha` (`estado`,`fecha`),
  KEY `idx_informes_tecnicos_accion` (`accion_requerida`),
  KEY `idx_informes_tecnicos_de_usuario_id` (`de_usuario_id`),
  KEY `idx_informes_tecnicos_emitido_por` (`emitido_por`),
  KEY `idx_informes_tecnicos_created_by` (`created_by`),
  CONSTRAINT `fk_informes_tecnicos_created_by` FOREIGN KEY (`created_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_informes_tecnicos_de_usuario_id` FOREIGN KEY (`de_usuario_id`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_informes_tecnicos_emitido_por` FOREIGN KEY (`emitido_por`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_informes_tecnicos_emitido` CHECK (`estado` = 'BORRADOR' or `numero` is not null and `anio` is not null and `correlativo` is not null and `emitido_at` is not null)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Informes técnicos de evaluación, inoperatividad y baja (BORRADOR -> EMITIDO)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `informes_tecnicos`
--

LOCK TABLES `informes_tecnicos` WRITE;
/*!40000 ALTER TABLE `informes_tecnicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `informes_tecnicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licencia_equipos`
--

DROP TABLE IF EXISTS `licencia_equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licencia_equipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `licencia_id` int(10) unsigned NOT NULL,
  `equipo_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `fecha_asignacion` datetime NOT NULL DEFAULT current_timestamp(),
  `asignado_por` int(10) unsigned DEFAULT NULL,
  `fecha_liberacion` datetime DEFAULT NULL,
  `motivo_liberacion` enum('FORMATEO','BAJA','REASIGNACION','OTRO') DEFAULT NULL,
  `liberado_por` int(10) unsigned DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  `slot_activo` tinyint(3) unsigned GENERATED ALWAYS AS (if(`fecha_liberacion` is null,`slot`,NULL)) STORED COMMENT 'Generada: slot ocupado (NULL si fue liberado)',
  `equipo_activo` int(10) unsigned GENERATED ALWAYS AS (if(`fecha_liberacion` is null,`equipo_id`,NULL)) STORED COMMENT 'Generada: equipo con licencia vigente (NULL si fue liberado)',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_licencia_equipos_slot_activo` (`licencia_id`,`slot_activo`),
  UNIQUE KEY `uq_licencia_equipos_equipo_activo` (`equipo_activo`),
  KEY `idx_licencia_equipos_equipo_id` (`equipo_id`),
  KEY `idx_licencia_equipos_licencia_liberacion` (`licencia_id`,`fecha_liberacion`),
  KEY `idx_licencia_equipos_asignado_por` (`asignado_por`),
  KEY `idx_licencia_equipos_liberado_por` (`liberado_por`),
  CONSTRAINT `fk_licencia_equipos_asignado_por` FOREIGN KEY (`asignado_por`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_licencia_equipos_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`),
  CONSTRAINT `fk_licencia_equipos_liberado_por` FOREIGN KEY (`liberado_por`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_licencia_equipos_licencia_id` FOREIGN KEY (`licencia_id`) REFERENCES `licencias_office` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_licencia_equipos_slot` CHECK (`slot` between 1 and 5),
  CONSTRAINT `chk_licencia_equipos_liberacion` CHECK (`fecha_liberacion` is null and `motivo_liberacion` is null and `liberado_por` is null or `fecha_liberacion` is not null and `motivo_liberacion` is not null),
  CONSTRAINT `chk_licencia_equipos_fechas` CHECK (`fecha_liberacion` is null or `fecha_liberacion` >= `fecha_asignacion`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Ocupación de slots (1-5) de cada licencia Office, con historial de liberaciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licencia_equipos`
--

LOCK TABLES `licencia_equipos` WRITE;
/*!40000 ALTER TABLE `licencia_equipos` DISABLE KEYS */;
/*!40000 ALTER TABLE `licencia_equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licencias_office`
--

DROP TABLE IF EXISTS `licencias_office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licencias_office` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) NOT NULL COMMENT 'Clave de producto (XXXXX-XXXXX-XXXXX-XXXXX-XXXXX)',
  `version` varchar(40) NOT NULL COMMENT 'p. ej. 2019, 2021, LTSC 2024',
  `edicion` varchar(80) DEFAULT NULL COMMENT 'p. ej. Hogar y Empresas, Professional Plus',
  `tipo_licencia` enum('OEM','RETAIL','VOLUMEN','OTRO') NOT NULL DEFAULT 'RETAIL',
  `fecha_adquisicion` date DEFAULT NULL,
  `orden_compra` varchar(50) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_licencias_office_clave` (`clave`),
  KEY `idx_licencias_office_version` (`version`),
  KEY `idx_licencias_office_activo` (`activo`),
  KEY `idx_licencias_office_created_by` (`created_by`),
  CONSTRAINT `fk_licencias_office_created_by` FOREIGN KEY (`created_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_licencias_office_activo` CHECK (`activo` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Licencias Microsoft Office (máximo 5 equipos por licencia)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licencias_office`
--

LOCK TABLES `licencias_office` WRITE;
/*!40000 ALTER TABLE `licencias_office` DISABLE KEYS */;
/*!40000 ALTER TABLE `licencias_office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mantenimiento_checklist`
--

DROP TABLE IF EXISTS `mantenimiento_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mantenimiento_checklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mantenimiento_id` int(10) unsigned NOT NULL,
  `checklist_item_id` int(10) unsigned NOT NULL,
  `realizado` tinyint(1) NOT NULL DEFAULT 0,
  `observacion` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mantenimiento_checklist_mant_item` (`mantenimiento_id`,`checklist_item_id`),
  KEY `idx_mantenimiento_checklist_item_id` (`checklist_item_id`),
  CONSTRAINT `fk_mantenimiento_checklist_checklist_item_id` FOREIGN KEY (`checklist_item_id`) REFERENCES `checklist_items` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimiento_checklist_mantenimiento_id` FOREIGN KEY (`mantenimiento_id`) REFERENCES `mantenimientos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_mantenimiento_checklist_realizado` CHECK (`realizado` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Actividades de checklist marcadas en cada acta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mantenimiento_checklist`
--

LOCK TABLES `mantenimiento_checklist` WRITE;
/*!40000 ALTER TABLE `mantenimiento_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `mantenimiento_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mantenimiento_componentes`
--

DROP TABLE IF EXISTS `mantenimiento_componentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mantenimiento_componentes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mantenimiento_id` int(10) unsigned NOT NULL,
  `componente` enum('HDD','SSD','RAM','FUENTE','PROCESADOR') NOT NULL,
  `accion` enum('REEMPLAZO','INSTALACION','NO_APLICA') NOT NULL DEFAULT 'NO_APLICA',
  `detalle` varchar(150) DEFAULT NULL COMMENT 'Serie o capacidad nueva',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mantenimiento_componentes_mant_comp` (`mantenimiento_id`,`componente`),
  CONSTRAINT `fk_mantenimiento_componentes_mantenimiento_id` FOREIGN KEY (`mantenimiento_id`) REFERENCES `mantenimientos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Componentes reemplazados o instalados en cada acta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mantenimiento_componentes`
--

LOCK TABLES `mantenimiento_componentes` WRITE;
/*!40000 ALTER TABLE `mantenimiento_componentes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mantenimiento_componentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mantenimiento_software`
--

DROP TABLE IF EXISTS `mantenimiento_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mantenimiento_software` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mantenimiento_id` int(10) unsigned NOT NULL,
  `software_id` int(10) unsigned NOT NULL,
  `version` varchar(40) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mantenimiento_software_mant_soft` (`mantenimiento_id`,`software_id`),
  KEY `idx_mantenimiento_software_software_id` (`software_id`),
  CONSTRAINT `fk_mantenimiento_software_mantenimiento_id` FOREIGN KEY (`mantenimiento_id`) REFERENCES `mantenimientos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimiento_software_software_id` FOREIGN KEY (`software_id`) REFERENCES `catalogo_software` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Software instalado en cada acta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mantenimiento_software`
--

LOCK TABLES `mantenimiento_software` WRITE;
/*!40000 ALTER TABLE `mantenimiento_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `mantenimiento_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mantenimientos`
--

DROP TABLE IF EXISTS `mantenimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mantenimientos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(30) DEFAULT NULL COMMENT 'N° 001-2026/OTIC-MANT; se asigna al cerrar',
  `anio` smallint(5) unsigned DEFAULT NULL,
  `correlativo` int(10) unsigned DEFAULT NULL,
  `equipo_id` int(10) unsigned NOT NULL,
  `personal_id` int(10) unsigned DEFAULT NULL COMMENT 'Snapshot del responsable al momento del servicio',
  `oficina_id` int(10) unsigned NOT NULL COMMENT 'Snapshot de la oficina al momento del servicio',
  `tecnico_id` int(10) unsigned NOT NULL,
  `tipo` enum('PREVENTIVO','CORRECTIVO') NOT NULL DEFAULT 'PREVENTIVO',
  `estado` enum('BORRADOR','CERRADA') NOT NULL DEFAULT 'BORRADOR',
  `fecha_ingreso` datetime NOT NULL,
  `fecha_salida` datetime DEFAULT NULL,
  `problema_reportado` text DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `recomendaciones` text DEFAULT NULL,
  `estado_equipo_previo` enum('OPERATIVO','EN_MANTENIMIENTO','INOPERATIVO','DE_BAJA') NOT NULL DEFAULT 'OPERATIVO' COMMENT 'Estado del equipo antes de abrir el acta',
  `estado_equipo_final` enum('OPERATIVO','EN_MANTENIMIENTO','INOPERATIVO','DE_BAJA') DEFAULT NULL COMMENT 'Estado elegido por el técnico al cerrar',
  `condicion_final` enum('BUENO','REGULAR','MALO') DEFAULT NULL,
  `pdf_ruta` varchar(255) DEFAULT NULL COMMENT 'Ruta relativa en storage/reports',
  `cerrado_por` int(10) unsigned DEFAULT NULL,
  `cerrado_at` datetime DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `borrador_equipo` int(10) unsigned GENERATED ALWAYS AS (if(`estado` = 'BORRADOR',`equipo_id`,NULL)) STORED COMMENT 'Generada: un solo borrador abierto por equipo',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mantenimientos_numero` (`numero`),
  UNIQUE KEY `uq_mantenimientos_anio_correlativo` (`anio`,`correlativo`),
  UNIQUE KEY `uq_mantenimientos_borrador_equipo` (`borrador_equipo`),
  KEY `idx_mantenimientos_equipo_estado_salida` (`equipo_id`,`estado`,`fecha_salida`),
  KEY `idx_mantenimientos_personal_id` (`personal_id`),
  KEY `idx_mantenimientos_oficina_id` (`oficina_id`),
  KEY `idx_mantenimientos_tecnico_id` (`tecnico_id`),
  KEY `idx_mantenimientos_estado_ingreso` (`estado`,`fecha_ingreso`),
  KEY `idx_mantenimientos_tipo` (`tipo`),
  KEY `idx_mantenimientos_cerrado_por` (`cerrado_por`),
  KEY `idx_mantenimientos_created_by` (`created_by`),
  CONSTRAINT `fk_mantenimientos_cerrado_por` FOREIGN KEY (`cerrado_por`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimientos_created_by` FOREIGN KEY (`created_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimientos_equipo_id` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`),
  CONSTRAINT `fk_mantenimientos_oficina_id` FOREIGN KEY (`oficina_id`) REFERENCES `oficinas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimientos_personal_id` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_mantenimientos_tecnico_id` FOREIGN KEY (`tecnico_id`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_mantenimientos_fechas` CHECK (`fecha_salida` is null or `fecha_salida` >= `fecha_ingreso`),
  CONSTRAINT `chk_mantenimientos_cerrada` CHECK (`estado` = 'BORRADOR' or `numero` is not null and `anio` is not null and `correlativo` is not null and `fecha_salida` is not null and `estado_equipo_final` is not null and `cerrado_at` is not null)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Actas de mantenimiento preventivo/correctivo (BORRADOR -> CERRADA)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mantenimientos`
--

LOCK TABLES `mantenimientos` WRITE;
/*!40000 ALTER TABLE `mantenimientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `mantenimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oficinas`
--

DROP TABLE IF EXISTS `oficinas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oficinas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `padre_id` int(10) unsigned DEFAULT NULL,
  `nombre` varchar(150) NOT NULL,
  `siglas` varchar(20) DEFAULT NULL,
  `tipo` enum('DIRECCION','DEPARTAMENTO','OFICINA') NOT NULL DEFAULT 'OFICINA',
  `ubicacion` varchar(150) DEFAULT NULL COMMENT 'Pabellón, piso o ambiente',
  `telefono` varchar(30) DEFAULT NULL COMMENT 'Anexo o teléfono',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oficinas_padre_nombre` (`padre_id`,`nombre`),
  KEY `idx_oficinas_nombre` (`nombre`),
  KEY `idx_oficinas_activo` (`activo`),
  CONSTRAINT `fk_oficinas_padre_id` FOREIGN KEY (`padre_id`) REFERENCES `oficinas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_oficinas_activo` CHECK (`activo` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Direcciones, departamentos y oficinas (árbol mediante padre_id)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oficinas`
--

LOCK TABLES `oficinas` WRITE;
/*!40000 ALTER TABLE `oficinas` DISABLE KEYS */;
INSERT INTO `oficinas` VALUES (1,NULL,'Dirección Académica','DA','DIRECCION',NULL,NULL,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(2,1,'Dpto. Diplomados','DD','DEPARTAMENTO',NULL,NULL,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(3,1,'Dpto. Evaluación','DE','DEPARTAMENTO',NULL,NULL,1,'2026-09-22 15:12:04','2026-09-22 15:12:04'),(4,NULL,'Oficina de Tecnologías de la Información y Comunicación','OTIC','OFICINA',NULL,NULL,1,'2026-09-22 15:12:04','2026-09-22 15:12:04');
/*!40000 ALTER TABLE `oficinas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parametros`
--

DROP TABLE IF EXISTS `parametros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parametros` (
  `clave` varchar(60) NOT NULL,
  `valor` text NOT NULL,
  `tipo` enum('TEXTO','ENTERO','DECIMAL','BOOLEANO','FECHA') NOT NULL DEFAULT 'TEXTO',
  `descripcion` varchar(255) DEFAULT NULL,
  `editable` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`clave`),
  KEY `idx_parametros_updated_by` (`updated_by`),
  CONSTRAINT `fk_parametros_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `usuarios_sistema` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_parametros_editable` CHECK (`editable` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Parámetros configurables del sistema (clave/valor)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parametros`
--

LOCK TABLES `parametros` WRITE;
/*!40000 ALTER TABLE `parametros` DISABLE KEYS */;
INSERT INTO `parametros` VALUES ('institucion_nombre','Centro de Altos Estudios Nacionales - Escuela de Posgrado (CAEN-EPG)','TEXTO','Nombre de la institución para encabezados de documentos',1,NULL,'2026-09-22 15:12:04','2026-09-22 15:12:04'),('jefe_otic_cargo','Jefe de la Oficina de Tecnologías de la Información y Comunicación','TEXTO','Cargo del Jefe de la OTIC',1,NULL,'2026-09-22 15:12:04','2026-09-22 15:12:04'),('jefe_otic_nombre','Registrar nombre del Jefe de la OTIC','TEXTO','Nombre del Jefe de la OTIC (destinatario por defecto de los informes técnicos)',1,NULL,'2026-09-22 15:12:04','2026-09-22 15:12:04'),('periodicidad_mant_meses','6','ENTERO','Meses entre mantenimientos preventivos (valor por defecto si el equipo no define el suyo)',1,NULL,'2026-09-22 15:12:04','2026-09-23 04:00:30'),('vida_util_meses_default','48','ENTERO','Vida útil sugerida en meses para equipos nuevos',1,NULL,'2026-09-22 15:12:04','2026-09-22 15:12:04');
/*!40000 ALTER TABLE `parametros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `dni` char(8) DEFAULT NULL,
  `cargo` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `oficina_id` int(10) unsigned NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_personal_dni` (`dni`),
  KEY `idx_personal_oficina_id` (`oficina_id`),
  KEY `idx_personal_apellidos_nombres` (`apellidos`,`nombres`),
  KEY `idx_personal_email` (`email`),
  KEY `idx_personal_activo` (`activo`),
  CONSTRAINT `fk_personal_oficina_id` FOREIGN KEY (`oficina_id`) REFERENCES `oficinas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_personal_activo` CHECK (`activo` in (0,1)),
  CONSTRAINT `chk_personal_dni` CHECK (`dni` is null or `dni` regexp '^[0-9]{8}$')
) ENGINE=InnoDB AUTO_INCREMENT=336 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Trabajadores institucionales responsables de equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal`
--

LOCK TABLES `personal` WRITE;
/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios_sistema`
--

DROP TABLE IF EXISTS `usuarios_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_sistema` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `dni` char(8) DEFAULT NULL,
  `cargo` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `rol` enum('ADMINISTRADOR','TECNICO') NOT NULL DEFAULT 'TECNICO',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `intentos_fallidos` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `debe_cambiar_password` tinyint(1) NOT NULL DEFAULT 0,
  `ultimo_acceso` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuarios_sistema_usuario` (`usuario`),
  UNIQUE KEY `uq_usuarios_sistema_email` (`email`),
  UNIQUE KEY `uq_usuarios_sistema_dni` (`dni`),
  KEY `idx_usuarios_sistema_rol_activo` (`rol`,`activo`),
  CONSTRAINT `chk_usuarios_sistema_activo` CHECK (`activo` in (0,1)),
  CONSTRAINT `chk_usuarios_sistema_debe_cambiar` CHECK (`debe_cambiar_password` in (0,1)),
  CONSTRAINT `chk_usuarios_sistema_dni` CHECK (`dni` is null or `dni` regexp '^[0-9]{8}$')
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Usuarios que inician sesión (ADMINISTRADOR / TECNICO)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_sistema`
--

LOCK TABLES `usuarios_sistema` WRITE;
/*!40000 ALTER TABLE `usuarios_sistema` DISABLE KEYS */;
INSERT INTO `usuarios_sistema` VALUES (1,'admin','$2y$10$V/rbUD2coqwdsCdKKgYTleiG3CDYPsEn70m900VVJXpXjR18kXzaS','Administrador','del Sistema',NULL,'Administrador SIGPAT-OTIC',NULL,'ADMINISTRADOR',1,0,NULL,0,'2026-09-23 10:23:32','2026-09-22 15:12:04','2026-09-23 10:23:32');
/*!40000 ALTER TABLE `usuarios_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_equipos_estado`
--

DROP TABLE IF EXISTS `v_equipos_estado`;
/*!50001 DROP VIEW IF EXISTS `v_equipos_estado`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_equipos_estado` AS SELECT
 1 AS `id`,
  1 AS `tipo`,
  1 AS `marca`,
  1 AS `modelo`,
  1 AS `nro_serie`,
  1 AS `codigo_patrimonial`,
  1 AS `codigo_interno`,
  1 AS `procesador`,
  1 AS `ram_gb`,
  1 AS `disco_tipo`,
  1 AS `disco_capacidad_gb`,
  1 AS `sistema_operativo`,
  1 AS `hostname`,
  1 AS `mac_lan`,
  1 AS `ip_lan`,
  1 AS `mac_wifi`,
  1 AS `oficina_id`,
  1 AS `oficina_nombre`,
  1 AS `oficina_siglas`,
  1 AS `personal_id`,
  1 AS `personal_nombre`,
  1 AS `personal_cargo`,
  1 AS `personal_dni`,
  1 AS `en_uso`,
  1 AS `estado_operativo`,
  1 AS `condicion_fisica`,
  1 AS `recomendado_baja`,
  1 AS `fecha_baja`,
  1 AS `fecha_adquisicion`,
  1 AS `vida_util_meses`,
  1 AS `valor_adquisicion`,
  1 AS `orden_compra`,
  1 AS `proveedor`,
  1 AS `garantia_hasta`,
  1 AS `observaciones`,
  1 AS `created_at`,
  1 AS `updated_at`,
  1 AS `codigo_inventario_anio`,
  1 AS `fecha_sugerida_baja`,
  1 AS `anios_antiguedad`,
  1 AS `fecha_ultimo_mantenimiento`,
  1 AS `periodicidad_efectiva_meses`,
  1 AS `licencia_id`,
  1 AS `licencia_slot`,
  1 AS `fecha_proximo_mantenimiento`,
  1 AS `dias_retraso_mantenimiento` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'sigpat_otic'
--

--
-- Final view structure for view `v_equipos_estado`
--

/*!50001 DROP VIEW IF EXISTS `v_equipos_estado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `v_equipos_estado` AS select `b`.`id` AS `id`,`b`.`tipo` AS `tipo`,`b`.`marca` AS `marca`,`b`.`modelo` AS `modelo`,`b`.`nro_serie` AS `nro_serie`,`b`.`codigo_patrimonial` AS `codigo_patrimonial`,`b`.`codigo_interno` AS `codigo_interno`,`b`.`procesador` AS `procesador`,`b`.`ram_gb` AS `ram_gb`,`b`.`disco_tipo` AS `disco_tipo`,`b`.`disco_capacidad_gb` AS `disco_capacidad_gb`,`b`.`sistema_operativo` AS `sistema_operativo`,`b`.`hostname` AS `hostname`,`b`.`mac_lan` AS `mac_lan`,`b`.`ip_lan` AS `ip_lan`,`b`.`mac_wifi` AS `mac_wifi`,`b`.`oficina_id` AS `oficina_id`,`b`.`oficina_nombre` AS `oficina_nombre`,`b`.`oficina_siglas` AS `oficina_siglas`,`b`.`personal_id` AS `personal_id`,`b`.`personal_nombre` AS `personal_nombre`,`b`.`personal_cargo` AS `personal_cargo`,`b`.`personal_dni` AS `personal_dni`,`b`.`en_uso` AS `en_uso`,`b`.`estado_operativo` AS `estado_operativo`,`b`.`condicion_fisica` AS `condicion_fisica`,`b`.`recomendado_baja` AS `recomendado_baja`,`b`.`fecha_baja` AS `fecha_baja`,`b`.`fecha_adquisicion` AS `fecha_adquisicion`,`b`.`vida_util_meses` AS `vida_util_meses`,`b`.`valor_adquisicion` AS `valor_adquisicion`,`b`.`orden_compra` AS `orden_compra`,`b`.`proveedor` AS `proveedor`,`b`.`garantia_hasta` AS `garantia_hasta`,`b`.`observaciones` AS `observaciones`,`b`.`created_at` AS `created_at`,`b`.`updated_at` AS `updated_at`,`b`.`codigo_inventario_anio` AS `codigo_inventario_anio`,`b`.`fecha_sugerida_baja` AS `fecha_sugerida_baja`,`b`.`anios_antiguedad` AS `anios_antiguedad`,`b`.`fecha_ultimo_mantenimiento` AS `fecha_ultimo_mantenimiento`,`b`.`periodicidad_efectiva_meses` AS `periodicidad_efectiva_meses`,`b`.`licencia_id` AS `licencia_id`,`b`.`licencia_slot` AS `licencia_slot`,coalesce(cast(`b`.`fecha_ultimo_mantenimiento` as date),`b`.`fecha_adquisicion`) + interval `b`.`periodicidad_efectiva_meses` month AS `fecha_proximo_mantenimiento`,case when coalesce(`b`.`fecha_ultimo_mantenimiento`,`b`.`fecha_adquisicion`) is null then NULL else to_days(curdate()) - to_days(coalesce(cast(`b`.`fecha_ultimo_mantenimiento` as date),`b`.`fecha_adquisicion`) + interval `b`.`periodicidad_efectiva_meses` month) end AS `dias_retraso_mantenimiento` from (select `e`.`id` AS `id`,`e`.`tipo` AS `tipo`,`e`.`marca` AS `marca`,`e`.`modelo` AS `modelo`,`e`.`nro_serie` AS `nro_serie`,`e`.`codigo_patrimonial` AS `codigo_patrimonial`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`procesador` AS `procesador`,`e`.`ram_gb` AS `ram_gb`,`e`.`disco_tipo` AS `disco_tipo`,`e`.`disco_capacidad_gb` AS `disco_capacidad_gb`,`e`.`sistema_operativo` AS `sistema_operativo`,`e`.`hostname` AS `hostname`,`e`.`mac_lan` AS `mac_lan`,`e`.`ip_lan` AS `ip_lan`,`e`.`mac_wifi` AS `mac_wifi`,`e`.`oficina_id` AS `oficina_id`,`o`.`nombre` AS `oficina_nombre`,`o`.`siglas` AS `oficina_siglas`,`e`.`personal_id` AS `personal_id`,case when `p`.`id` is null then NULL else concat(`p`.`nombres`,' ',`p`.`apellidos`) end AS `personal_nombre`,`p`.`cargo` AS `personal_cargo`,`p`.`dni` AS `personal_dni`,if(`e`.`personal_id` is not null,1,0) AS `en_uso`,`e`.`estado_operativo` AS `estado_operativo`,`e`.`condicion_fisica` AS `condicion_fisica`,`e`.`recomendado_baja` AS `recomendado_baja`,`e`.`fecha_baja` AS `fecha_baja`,`e`.`fecha_adquisicion` AS `fecha_adquisicion`,`e`.`vida_util_meses` AS `vida_util_meses`,`e`.`valor_adquisicion` AS `valor_adquisicion`,`e`.`orden_compra` AS `orden_compra`,`e`.`proveedor` AS `proveedor`,`e`.`garantia_hasta` AS `garantia_hasta`,`e`.`observaciones` AS `observaciones`,`e`.`created_at` AS `created_at`,`e`.`updated_at` AS `updated_at`,(select `ec`.`codigo` from `equipo_codigos` `ec` where `ec`.`equipo_id` = `e`.`id` and `ec`.`anio` = year(curdate())) AS `codigo_inventario_anio`,`e`.`fecha_adquisicion` + interval `e`.`vida_util_meses` month AS `fecha_sugerida_baja`,timestampdiff(YEAR,`e`.`fecha_adquisicion`,curdate()) AS `anios_antiguedad`,`um`.`fecha_ultimo_mantenimiento` AS `fecha_ultimo_mantenimiento`,coalesce(`e`.`periodicidad_mant_meses`,(select cast(`pa`.`valor` as unsigned) from `parametros` `pa` where `pa`.`clave` = 'periodicidad_mant_meses'),6) AS `periodicidad_efectiva_meses`,`le`.`licencia_id` AS `licencia_id`,`le`.`slot` AS `licencia_slot` from ((((`equipos` `e` join `oficinas` `o` on(`o`.`id` = `e`.`oficina_id`)) left join `personal` `p` on(`p`.`id` = `e`.`personal_id`)) left join (select `m`.`equipo_id` AS `equipo_id`,max(`m`.`fecha_salida`) AS `fecha_ultimo_mantenimiento` from `mantenimientos` `m` where `m`.`estado` = 'CERRADA' group by `m`.`equipo_id`) `um` on(`um`.`equipo_id` = `e`.`id`)) left join `licencia_equipos` `le` on(`le`.`equipo_activo` = `e`.`id`))) `b` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-23 17:25:04
